﻿'Prologue


Public Class frmFinanceCharges

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        End

    End Sub

    Private Sub btnCharges_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCharges.Click
        Const sngFinanceRate As Single = 0.015
        Dim srdFinanceCharges As System.IO.StreamReader
        Dim strLine As String

        Dim strRecord() As String
        Dim strLast As String
        Dim strFirst As String
        Dim strAcctNo As String
        Dim decBalance As Decimal
        Dim decFinanceCharge As Decimal
        Dim decTotal As Decimal

        'Display header
        rtbOut.Clear()
        rtbOut.AppendText("                Monthly Finance Charges" & vbNewLine & vbNewLine)
        rtbOut.AppendText("Last Name   First Name  Acct. No.    Balance    Charges" & vbNewLine)

        'Open file
        srdFinanceCharges = New System.IO.StreamReader("FinanceCharges.dat")

        Do Until srdFinanceCharges.Peek = -1
            'Input
            'Reads record
            strLine = srdFinanceCharges.ReadLine

            'Splits record
            strRecord = strLine.Split(",")
            strLast = strRecord(0)
            strFirst = strRecord(1)
            strAcctNo = strRecord(2)
            decBalance = Convert.ToDecimal(strRecord(3))

            'Processing
            decFinanceCharge = decBalance * sngFinanceRate
            decTotal += decFinanceCharge

            'Output
            rtbOut.AppendText(strLast.PadRight(12) & strFirst.PadRight(12) & _
            strAcctNo.PadRight(10) & decBalance.ToString("c").PadLeft(11) & _
            decFinanceCharge.ToString("c").PadLeft(10) & vbNewLine)

        Loop

        'Post-processing
        'Close file
        srdFinanceCharges.Close()

        'Display total
        rtbOut.AppendText("Total Charges:" & decTotal.ToString("c").PadLeft(41) & vbNewLine)

    End Sub
End Class
