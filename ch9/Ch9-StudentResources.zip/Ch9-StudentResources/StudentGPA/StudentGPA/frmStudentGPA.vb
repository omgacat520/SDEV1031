﻿'Prologue


Public Class frmStudentGPA

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        End

    End Sub

    Private Sub btnRead_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRead.Click
        Dim srdFile As System.IO.StreamReader
        Dim strLine As String

        rtbOut.Clear()
        rtbOut.AppendText(" Student GPA" & ControlChars.NewLine & ControlChars.NewLine)

        srdFile = New System.IO.StreamReader("GPA.dat")

        Do Until srdFile.Peek = -1
            'Read
            strLine = srdFile.ReadLine()
            rtbOut.AppendText(strLine & vbNewLine)

        Loop
        srdFile.Close()

    End Sub
End Class
