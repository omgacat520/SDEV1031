﻿'Prologue



Public Class frmSaveBowlingScores

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        End

    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        'Declarations
        Dim swrBowlingScores As System.IO.StreamWriter
        Dim strFirst As String
        Dim strLast As String
        Dim shoGame1 As Short
        Dim shoGame2 As Short
        Dim shoGame3 As Short
        Dim strDetail As String

        'Pre-processing
        swrBowlingScores = IO.File.AppendText("BowlingScores.dat")

        'Input
        strFirst = txtFirst.Text
        strLast = txtLast.Text
        shoGame1 = tbrGame1.Value
        shoGame2 = tbrGame2.Value
        shoGame3 = tbrGame3.Value

        'Processing
        strDetail = strFirst & "," & strLast & "," & _
        shoGame1.ToString & "," & shoGame2.ToString & _
        "," & shoGame3.ToString

        'Output
        swrBowlingScores.WriteLine(strDetail)

        'Post-processing
        swrBowlingScores.Close()

    End Sub

    Private Sub tbrGame1_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbrGame1.Scroll
        lblGame1.Text = tbrGame1.Value

    End Sub

    Private Sub tbrGame2_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbrGame2.Scroll
        lblGame2.Text = tbrGame2.Value

    End Sub

    Private Sub tbrGame3_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbrGame3.Scroll
        lblGame3.Text = tbrGame3.Value

    End Sub
End Class
