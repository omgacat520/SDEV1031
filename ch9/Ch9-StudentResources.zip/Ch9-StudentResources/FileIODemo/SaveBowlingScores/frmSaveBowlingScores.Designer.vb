﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSaveBowlingScores
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtFirst = New System.Windows.Forms.TextBox
        Me.txtLast = New System.Windows.Forms.TextBox
        Me.tbrGame1 = New System.Windows.Forms.TrackBar
        Me.tbrGame2 = New System.Windows.Forms.TrackBar
        Me.tbrGame3 = New System.Windows.Forms.TrackBar
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.btnSave = New System.Windows.Forms.Button
        Me.btnExit = New System.Windows.Forms.Button
        Me.lblGame1 = New System.Windows.Forms.Label
        Me.lblGame2 = New System.Windows.Forms.Label
        Me.lblGame3 = New System.Windows.Forms.Label
        CType(Me.tbrGame1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tbrGame2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tbrGame3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtFirst
        '
        Me.txtFirst.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFirst.Location = New System.Drawing.Point(28, 22)
        Me.txtFirst.Name = "txtFirst"
        Me.txtFirst.Size = New System.Drawing.Size(170, 26)
        Me.txtFirst.TabIndex = 0
        '
        'txtLast
        '
        Me.txtLast.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLast.Location = New System.Drawing.Point(28, 57)
        Me.txtLast.Name = "txtLast"
        Me.txtLast.Size = New System.Drawing.Size(170, 26)
        Me.txtLast.TabIndex = 1
        '
        'tbrGame1
        '
        Me.tbrGame1.Location = New System.Drawing.Point(28, 105)
        Me.tbrGame1.Maximum = 300
        Me.tbrGame1.Name = "tbrGame1"
        Me.tbrGame1.Size = New System.Drawing.Size(391, 45)
        Me.tbrGame1.TabIndex = 2
        '
        'tbrGame2
        '
        Me.tbrGame2.Location = New System.Drawing.Point(28, 156)
        Me.tbrGame2.Maximum = 300
        Me.tbrGame2.Name = "tbrGame2"
        Me.tbrGame2.Size = New System.Drawing.Size(391, 45)
        Me.tbrGame2.TabIndex = 3
        '
        'tbrGame3
        '
        Me.tbrGame3.Location = New System.Drawing.Point(28, 207)
        Me.tbrGame3.Maximum = 300
        Me.tbrGame3.Name = "tbrGame3"
        Me.tbrGame3.Size = New System.Drawing.Size(391, 45)
        Me.tbrGame3.TabIndex = 4
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(204, 25)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(100, 23)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "First Name"
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(204, 60)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(100, 23)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Last Name"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(36, 138)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(51, 23)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Game 1"
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(36, 189)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(51, 23)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "Game 2"
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(36, 241)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(51, 23)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "Game 3"
        '
        'btnSave
        '
        Me.btnSave.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSave.Location = New System.Drawing.Point(208, 290)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(75, 30)
        Me.btnSave.TabIndex = 10
        Me.btnSave.Text = "&Save"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(305, 290)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 30)
        Me.btnExit.TabIndex = 11
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblGame1
        '
        Me.lblGame1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGame1.Location = New System.Drawing.Point(429, 116)
        Me.lblGame1.Name = "lblGame1"
        Me.lblGame1.Size = New System.Drawing.Size(51, 23)
        Me.lblGame1.TabIndex = 12
        Me.lblGame1.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblGame2
        '
        Me.lblGame2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGame2.Location = New System.Drawing.Point(429, 166)
        Me.lblGame2.Name = "lblGame2"
        Me.lblGame2.Size = New System.Drawing.Size(51, 23)
        Me.lblGame2.TabIndex = 13
        Me.lblGame2.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblGame3
        '
        Me.lblGame3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGame3.Location = New System.Drawing.Point(429, 218)
        Me.lblGame3.Name = "lblGame3"
        Me.lblGame3.Size = New System.Drawing.Size(51, 23)
        Me.lblGame3.TabIndex = 14
        Me.lblGame3.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'frmSaveBowlingScores
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(492, 341)
        Me.Controls.Add(Me.lblGame3)
        Me.Controls.Add(Me.lblGame2)
        Me.Controls.Add(Me.lblGame1)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.tbrGame3)
        Me.Controls.Add(Me.tbrGame2)
        Me.Controls.Add(Me.tbrGame1)
        Me.Controls.Add(Me.txtLast)
        Me.Controls.Add(Me.txtFirst)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmSaveBowlingScores"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Lucky Strikes Bowling League"
        CType(Me.tbrGame1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tbrGame2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tbrGame3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtFirst As System.Windows.Forms.TextBox
    Friend WithEvents txtLast As System.Windows.Forms.TextBox
    Friend WithEvents tbrGame1 As System.Windows.Forms.TrackBar
    Friend WithEvents tbrGame2 As System.Windows.Forms.TrackBar
    Friend WithEvents tbrGame3 As System.Windows.Forms.TrackBar
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents lblGame1 As System.Windows.Forms.Label
    Friend WithEvents lblGame2 As System.Windows.Forms.Label
    Friend WithEvents lblGame3 As System.Windows.Forms.Label

End Class
