﻿Public Class Form1
    Dim mstrName As String = "Stranger"
    Private Sub btnGreetings_Click(sender As Object, e As EventArgs) Handles btnGreetings.Click

        mstrName = InputBox("Greetings, whats ya name?", "Greetings")

        MessageBox.Show("Your name is " & mstrName, "Greetings", MessageBoxButtons.YesNo)

        rtbOutput.AppendText("Your name is " & mstrName & vbNewLine)
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        rtbOutput.AppendText("What's up?" & vbNewLine)
    End Sub

    Private Sub btnHobby_Click(sender As Object, e As EventArgs) Handles btnHobby.Click
        Dim strHobby As String
        strHobby = InputBox("What's your favorite hobby?", "Tell me your hobby")

        MessageBox.Show("Your favorite hobby is " & strHobby, "Hobby", MessageBoxButtons.YesNo)

        rtbOutput.AppendText(mstrName & "'s favorite hobby is " & strHobby & vbNewLine)
    End Sub

    Private Sub btnFood_Click(sender As Object, e As EventArgs) Handles btnFood.Click
        Dim strFood As String
        strFood = InputBox("Whats your favorite food?", "Tell me your favorite food")

        MessageBox.Show("Your favorite food is " & strFood, "Food", MessageBoxButtons.YesNo)

        rtbOutput.AppendText(mstrName & "'s favorite food is " & strFood & vbNewLine)
    End Sub

    Private Sub btnSeason_Click(sender As Object, e As EventArgs) Handles btnSeason.Click
        Dim strSeason As String
        strSeason = InputBox("Whats your favorite Season?", "Tell me your favorite Season")

        MessageBox.Show("Your favorite Season is " & strSeason, "Season", MessageBoxButtons.YesNo)

        rtbOutput.AppendText(mstrName & "'s favorite Season is " & strSeason & vbNewLine)
    End Sub
End Class
