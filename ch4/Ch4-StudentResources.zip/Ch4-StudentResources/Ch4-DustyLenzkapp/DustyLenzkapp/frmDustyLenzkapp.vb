'Prologue

Public Class frmDustyLenzkapp
    'Total sales for the day


    Private Sub frmDustyLenzkapp_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'Clears the rtb and adds a header
        rtbOutput.Clear()
        rtbOutput.AppendText("         Dusty Lenzkapp's Camerarama" & vbNewLine)
        rtbOutput.AppendText("             Daily Sales Totals" & vbNewLine & vbNewLine)
        rtbOutput.AppendText("Employee        Sales   Rate  Commission" & vbNewLine)

    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        'Clears the rtb and adds a header
        rtbOutput.Clear()

    End Sub

    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        'Finds and displays today's date

        Dim datToday As Date

        datToday = Now()

        lblDate.Text = datToday.ToLongDateString

        'Calculates commission and adds a detail line
        Dim decTotalSales As Decimal
        Dim strName As String
        Dim decSales As Decimal
        Dim sngCommRate As Single
        Dim decComm As Decimal
        Dim strOut As String

        'Input
        strName = txtName.Text
        decSales = Convert.ToDecimal(txtSales.Text)
        sngCommRate = nudCommRate.Value

        'Processing
        decComm = sngCommRate * decSales
        decTotalSales = decTotalSales + 1
        'Output
        strOut = strName & ControlChars.Tab & sngCommRate.ToString("p1") & ControlChars.Tab & decSales.ToString("c") & ControlChars.Tab & decComm.ToString("c") & vbNewLine
        rtbOutput.AppendText(strOut)
        'Display total
        rtbOutput.AppendText("Total       " & decTotalSales.ToString("c"))

    End Sub

    Private Sub btnTotal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTotal.Click

    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        End

    End Sub

End Class
