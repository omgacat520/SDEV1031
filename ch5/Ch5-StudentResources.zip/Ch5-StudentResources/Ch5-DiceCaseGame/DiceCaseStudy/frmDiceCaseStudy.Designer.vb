<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDiceCaseStudy
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmDiceCaseStudy))
        Me.btnEven = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblTotal = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.picDie26 = New System.Windows.Forms.PictureBox()
        Me.picDie25 = New System.Windows.Forms.PictureBox()
        Me.picDie24 = New System.Windows.Forms.PictureBox()
        Me.picDie23 = New System.Windows.Forms.PictureBox()
        Me.picDie22 = New System.Windows.Forms.PictureBox()
        Me.picDie21 = New System.Windows.Forms.PictureBox()
        Me.picDie16 = New System.Windows.Forms.PictureBox()
        Me.picDie15 = New System.Windows.Forms.PictureBox()
        Me.picDie14 = New System.Windows.Forms.PictureBox()
        Me.picDie13 = New System.Windows.Forms.PictureBox()
        Me.picDie12 = New System.Windows.Forms.PictureBox()
        Me.picDie11 = New System.Windows.Forms.PictureBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblResult = New System.Windows.Forms.Label()
        CType(Me.picDie26, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picDie25, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picDie24, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picDie23, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picDie22, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picDie21, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picDie16, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picDie15, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picDie14, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picDie13, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picDie12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picDie11, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnEven
        '
        Me.btnEven.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEven.Location = New System.Drawing.Point(146, 174)
        Me.btnEven.Name = "btnEven"
        Me.btnEven.Size = New System.Drawing.Size(75, 30)
        Me.btnEven.TabIndex = 12
        Me.btnEven.Text = "Even"
        Me.btnEven.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(184, 364)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 30)
        Me.btnExit.TabIndex = 13
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblTotal
        '
        Me.lblTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotal.Location = New System.Drawing.Point(123, 119)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(49, 30)
        Me.lblTotal.TabIndex = 14
        Me.lblTotal.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(178, 127)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(57, 23)
        Me.Label1.TabIndex = 15
        Me.Label1.Text = "Total"
        '
        'picDie26
        '
        Me.picDie26.Image = Global.DiceCaseStudy.My.Resources.Resources.dice61
        Me.picDie26.Location = New System.Drawing.Point(164, 53)
        Me.picDie26.Name = "picDie26"
        Me.picDie26.Size = New System.Drawing.Size(46, 46)
        Me.picDie26.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picDie26.TabIndex = 11
        Me.picDie26.TabStop = False
        Me.picDie26.Visible = False
        '
        'picDie25
        '
        Me.picDie25.Image = Global.DiceCaseStudy.My.Resources.Resources.dice51
        Me.picDie25.Location = New System.Drawing.Point(164, 53)
        Me.picDie25.Name = "picDie25"
        Me.picDie25.Size = New System.Drawing.Size(46, 46)
        Me.picDie25.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picDie25.TabIndex = 10
        Me.picDie25.TabStop = False
        Me.picDie25.Visible = False
        '
        'picDie24
        '
        Me.picDie24.Image = Global.DiceCaseStudy.My.Resources.Resources.dice41
        Me.picDie24.Location = New System.Drawing.Point(164, 53)
        Me.picDie24.Name = "picDie24"
        Me.picDie24.Size = New System.Drawing.Size(46, 46)
        Me.picDie24.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picDie24.TabIndex = 9
        Me.picDie24.TabStop = False
        Me.picDie24.Visible = False
        '
        'picDie23
        '
        Me.picDie23.Image = Global.DiceCaseStudy.My.Resources.Resources.dice31
        Me.picDie23.Location = New System.Drawing.Point(164, 53)
        Me.picDie23.Name = "picDie23"
        Me.picDie23.Size = New System.Drawing.Size(46, 46)
        Me.picDie23.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picDie23.TabIndex = 8
        Me.picDie23.TabStop = False
        Me.picDie23.Visible = False
        '
        'picDie22
        '
        Me.picDie22.Image = Global.DiceCaseStudy.My.Resources.Resources.dice21
        Me.picDie22.Location = New System.Drawing.Point(164, 53)
        Me.picDie22.Name = "picDie22"
        Me.picDie22.Size = New System.Drawing.Size(46, 46)
        Me.picDie22.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picDie22.TabIndex = 7
        Me.picDie22.TabStop = False
        Me.picDie22.Visible = False
        '
        'picDie21
        '
        Me.picDie21.Image = Global.DiceCaseStudy.My.Resources.Resources.dice11
        Me.picDie21.Location = New System.Drawing.Point(164, 53)
        Me.picDie21.Name = "picDie21"
        Me.picDie21.Size = New System.Drawing.Size(46, 46)
        Me.picDie21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picDie21.TabIndex = 6
        Me.picDie21.TabStop = False
        Me.picDie21.Visible = False
        '
        'picDie16
        '
        Me.picDie16.Image = Global.DiceCaseStudy.My.Resources.Resources.dice61
        Me.picDie16.Location = New System.Drawing.Point(85, 53)
        Me.picDie16.Name = "picDie16"
        Me.picDie16.Size = New System.Drawing.Size(46, 46)
        Me.picDie16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picDie16.TabIndex = 5
        Me.picDie16.TabStop = False
        Me.picDie16.Visible = False
        '
        'picDie15
        '
        Me.picDie15.Image = Global.DiceCaseStudy.My.Resources.Resources.dice51
        Me.picDie15.Location = New System.Drawing.Point(85, 53)
        Me.picDie15.Name = "picDie15"
        Me.picDie15.Size = New System.Drawing.Size(46, 46)
        Me.picDie15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picDie15.TabIndex = 4
        Me.picDie15.TabStop = False
        Me.picDie15.Visible = False
        '
        'picDie14
        '
        Me.picDie14.Image = Global.DiceCaseStudy.My.Resources.Resources.dice41
        Me.picDie14.Location = New System.Drawing.Point(85, 53)
        Me.picDie14.Name = "picDie14"
        Me.picDie14.Size = New System.Drawing.Size(46, 46)
        Me.picDie14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picDie14.TabIndex = 3
        Me.picDie14.TabStop = False
        Me.picDie14.Visible = False
        '
        'picDie13
        '
        Me.picDie13.Image = Global.DiceCaseStudy.My.Resources.Resources.dice31
        Me.picDie13.Location = New System.Drawing.Point(85, 53)
        Me.picDie13.Name = "picDie13"
        Me.picDie13.Size = New System.Drawing.Size(46, 46)
        Me.picDie13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picDie13.TabIndex = 2
        Me.picDie13.TabStop = False
        Me.picDie13.Visible = False
        '
        'picDie12
        '
        Me.picDie12.Image = Global.DiceCaseStudy.My.Resources.Resources.dice21
        Me.picDie12.Location = New System.Drawing.Point(85, 53)
        Me.picDie12.Name = "picDie12"
        Me.picDie12.Size = New System.Drawing.Size(46, 46)
        Me.picDie12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picDie12.TabIndex = 1
        Me.picDie12.TabStop = False
        Me.picDie12.Visible = False
        '
        'picDie11
        '
        Me.picDie11.Image = Global.DiceCaseStudy.My.Resources.Resources.dice11
        Me.picDie11.Location = New System.Drawing.Point(85, 53)
        Me.picDie11.Name = "picDie11"
        Me.picDie11.Size = New System.Drawing.Size(46, 46)
        Me.picDie11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picDie11.TabIndex = 0
        Me.picDie11.TabStop = False
        Me.picDie11.Visible = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(65, 9)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(172, 29)
        Me.Label2.TabIndex = 16
        Me.Label2.Text = "Even or Odd?"
        '
        'lblResult
        '
        Me.lblResult.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblResult.Location = New System.Drawing.Point(70, 229)
        Me.lblResult.Name = "lblResult"
        Me.lblResult.Size = New System.Drawing.Size(151, 60)
        Me.lblResult.TabIndex = 17
        Me.lblResult.Text = "Result"
        '
        'frmDiceCaseStudy
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(292, 415)
        Me.Controls.Add(Me.lblResult)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblTotal)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnEven)
        Me.Controls.Add(Me.picDie26)
        Me.Controls.Add(Me.picDie25)
        Me.Controls.Add(Me.picDie24)
        Me.Controls.Add(Me.picDie23)
        Me.Controls.Add(Me.picDie22)
        Me.Controls.Add(Me.picDie21)
        Me.Controls.Add(Me.picDie16)
        Me.Controls.Add(Me.picDie15)
        Me.Controls.Add(Me.picDie14)
        Me.Controls.Add(Me.picDie13)
        Me.Controls.Add(Me.picDie12)
        Me.Controls.Add(Me.picDie11)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmDiceCaseStudy"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "A Roll of the Dice"
        CType(Me.picDie26, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picDie25, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picDie24, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picDie23, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picDie22, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picDie21, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picDie16, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picDie15, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picDie14, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picDie13, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picDie12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picDie11, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents picDie11 As System.Windows.Forms.PictureBox
    Friend WithEvents picDie12 As System.Windows.Forms.PictureBox
    Friend WithEvents picDie13 As System.Windows.Forms.PictureBox
    Friend WithEvents picDie14 As System.Windows.Forms.PictureBox
    Friend WithEvents picDie15 As System.Windows.Forms.PictureBox
    Friend WithEvents picDie16 As System.Windows.Forms.PictureBox
    Friend WithEvents picDie26 As System.Windows.Forms.PictureBox
    Friend WithEvents picDie25 As System.Windows.Forms.PictureBox
    Friend WithEvents picDie24 As System.Windows.Forms.PictureBox
    Friend WithEvents picDie23 As System.Windows.Forms.PictureBox
    Friend WithEvents picDie22 As System.Windows.Forms.PictureBox
    Friend WithEvents picDie21 As System.Windows.Forms.PictureBox
    Friend WithEvents btnEven As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents lblTotal As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents lblResult As System.Windows.Forms.Label

End Class
