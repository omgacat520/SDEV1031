Public Class frmCookies

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        End

    End Sub

    Private Sub btnStart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStart.Click
        'Declarations
        Dim strLast() As String
        Dim strFirst() As String
        Dim shoCase() As Short
        Dim shoCount As Short
        Dim strRead As String
        Dim strField() As String
        Dim srdReader As System.IO.StreamReader

        'Clear rich text box
        rtbOut.Clear()

        'Open file
        srdReader = IO.File.OpenText("Cookies.dat")

        Do
            'Resize array and keep existing data
            ReDim Preserve strLast(shoCount)
            ReDim Preserve strFirst(shoCount)
            ReDim Preserve shoCase(shoCount)

            'Read record and parse it
            strRead = srdReader.ReadLine()
            strField = strRead.Split(",")
            strFirst(shoCount) = strField(0)
            strLast(shoCount) = strField(1)
            shoCase(shoCount) = strField(2)

            'Display output
            rtbOut.AppendText(strFirst(shoCount).ToString.PadRight(8) & strLast(shoCount).ToString.PadRight(8) & _
            shoCase(shoCount).ToString.PadLeft(4) & vbNewLine)
            shoCount = shoCount + 1

        Loop Until srdReader.Peek = -1

        'Close file
        srdReader.Close()
    End Sub
End Class
