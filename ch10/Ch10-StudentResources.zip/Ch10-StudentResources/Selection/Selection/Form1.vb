Public Class Form1

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        End

    End Sub

    Private Sub btnSort_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSort.Click
        Dim strDVD() As String = {"Grease", "African Queen", "Zulu", "Saving Private Ryan", "American Graffiti"}
        Dim i, j As Integer
        Dim intMin As Integer
        Dim strTemp As String

        rtbOut.Clear()

        For i = 0 To strDVD.GetUpperBound(0) - 1
            intMin = i
            For j = i + 1 To strDVD.GetUpperBound(0)
                If strDVD(intMin) > strDVD(j) Then
                    intMin = j
                End If
            Next j
            strTemp = strDVD(i)
            strDVD(i) = strDVD(intMin)
            strDVD(intMin) = strTemp
        Next i

        For i = 0 To 4
            rtbOut.AppendText(strDVD(i) & ControlChars.NewLine)

        Next

    End Sub
End Class
