'Prologue

Public Class frmSelectionSort

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        'Exit
        End

    End Sub

    Private Sub btnSort_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSort.Click
        'Declarations
        Dim strDVD() As String = {"Grease", "African Queen", "Zulu", "Saving Private Ryan", "American Graffiti"}
        Dim i, j As Integer
        Dim intMin As Integer
        Dim strTemp As String

        rtbOut.Clear()
        rtbOut.AppendText("Unsorted: " & vbNewLine)
        For i = 0 To 4
            rtbOut.AppendText(strDVD(i) & vbNewLine)

        Next i

        'Selection sort
        For i = 0 To strDVD.GetUpperBound(0) - 1
            intMin = i
            For j = i + 1 To strDVD.GetUpperBound(0)
                If strDVD(intMin) > strDVD(j) Then
                    intMin = j
                End If
            Next j
            strTemp = strDVD(i)
            strDVD(i) = strDVD(intMin)
            strDVD(intMin) = strTemp
        Next i

        'Output
        rtbOut.AppendText(vbNewLine & "Sorted: " & vbNewLine)
        For i = 0 To 4
            rtbOut.AppendText(strDVD(i) & vbNewLine)

        Next i

    End Sub
End Class
