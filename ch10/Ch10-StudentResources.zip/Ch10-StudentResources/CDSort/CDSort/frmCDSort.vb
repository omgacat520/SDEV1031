Public Class frmCDSort

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        End

    End Sub

    Private Sub btnSort_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSort.Click
        Dim strArtist() As String
        Dim strAlbum() As String
        Dim strGenre() As String
        Dim strField() As String
        Dim srdFile As System.IO.StreamReader
        Dim strLine As String
        Dim intCount As Integer
        Dim i, j As Integer
        Dim strSwap As String
        Dim strDetail As String

        rtbOut.Clear()
        rtbOut.AppendText("                     Sorted CD Collection" & vbNewLine & vbNewLine)
        rtbOut.AppendText("Artist               Title                            Genre")
        rtbOut.AppendText(vbNewLine)

        'Open File
        ofdCDSort.ShowDialog()
        srdFile = New System.IO.StreamReader(ofdCDSort.FileName)

        'Read

        Do While srdFile.Peek <> -1

            'Parse
            ReDim Preserve strArtist(intCount)
            ReDim Preserve strAlbum(intCount)
            ReDim Preserve strGenre(intCount)
            strLine = srdFile.ReadLine()

            strField = strLine.Split(",")

            strArtist(intCount) = strField(0)
            strAlbum(intCount) = strField(1)
            strGenre(intCount) = strField(2)

            intCount = intCount + 1

        Loop

        'Close
        srdFile.Close()

        'Sort
        intCount = 1
        For i = strArtist.GetLowerBound(0) To strArtist.GetUpperBound(0) - 1
            For j = strArtist.GetLowerBound(0) To strArtist.GetUpperBound(0) - i - 1
                If strArtist(j) > strArtist(j + 1) Then
                    strSwap = strArtist(j)
                    strArtist(j) = strArtist(j + 1)
                    strArtist(j + 1) = strSwap
                    strSwap = strAlbum(j)
                    strAlbum(j) = strAlbum(j + 1)
                    strAlbum(j + 1) = strSwap
                    strSwap = strGenre(j)
                    strGenre(j) = strGenre(j + 1)
                    strGenre(j + 1) = strSwap

                End If
            Next j
            intCount += 1
            lblCount.Text = intCount.ToString
            lblCount.Refresh()

        Next i

        'Output
        For i = 0 To strArtist.GetUpperBound(0)
            strDetail = strArtist(i).PadRight(20) & _
            strAlbum(i).PadRight(33) & strGenre(i).PadRight(18)

            rtbOut.AppendText(strDetail & vbNewLine)

        Next i
    End Sub
End Class
