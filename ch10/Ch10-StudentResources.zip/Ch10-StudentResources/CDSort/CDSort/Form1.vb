Public Class Form1

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        End

    End Sub

    Private Sub btnSort_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSort.Click
        Dim strArtist() As String
        Dim strAlbum() As String
        Dim strGenre() As String
        Dim strField() As String
        Dim srdFile As System.IO.StreamReader
        Dim strLine As String
        Const chrDelimiter As Char = ","
        Dim intCount As Integer
        Dim i, j As Integer
        Dim strSwap As String
        Dim strDetail As String

        rtbOut.Clear()
        rtbOut.AppendText("                     Sorted CD Collection")
        rtbOut.AppendText(ControlChars.NewLine & ControlChars.NewLine)
        rtbOut.AppendText("Artist               Title                            Genre")
        rtbOut.AppendText(ControlChars.NewLine)

        'Open File
        ofdCDSort.ShowDialog()
        srdFile = New System.IO.StreamReader(ofdCDSort.FileName)

        'Read
        strLine = srdFile.ReadLine()

        Do While (strLine <> Nothing)

            'Parse
            ReDim Preserve strArtist(intCount)
            ReDim Preserve strAlbum(intCount)
            ReDim Preserve strGenre(intCount)

            strField = strLine.Split(chrDelimiter)

            strArtist(intCount) = strField(0)
            strAlbum(intCount) = strField(1)
            strGenre(intCount) = strField(2)

            strLine = srdFile.ReadLine()
            intCount = intCount + 1
        Loop

        'Close
        srdFile.Close()

        'Sort
        For i = strArtist.GetLowerBound(0) To strArtist.GetUpperBound(0) - 1
            For j = strArtist.GetLowerBound(0) To strArtist.GetUpperBound(0) - i - 1
                If strArtist(j) > strArtist(j + 1) Then
                    strSwap = strArtist(j)
                    strArtist(j) = strArtist(j + 1)
                    strArtist(j + 1) = strSwap
                    strSwap = strAlbum(j)
                    strAlbum(j) = strAlbum(j + 1)
                    strAlbum(j + 1) = strSwap
                    strSwap = strGenre(j)
                    strGenre(j) = strGenre(j + 1)
                    strGenre(j + 1) = strSwap

                End If
            Next j
        Next i

        'Output
        For i = 0 To strArtist.GetUpperBound(0)
            strDetail = strArtist(i).PadRight(20) & _
            strAlbum(i).PadRight(33) & _
            strGenre(i).PadRight(18)

            rtbOut.AppendText(strDetail & ControlChars.NewLine)

        Next i
    End Sub
End Class
