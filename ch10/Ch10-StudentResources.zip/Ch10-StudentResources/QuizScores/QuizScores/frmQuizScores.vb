﻿'Prologue

Public Class frmQuizScores

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        End

    End Sub

    Private Sub btnStart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStart.Click
        'Display quiz scores 
        Dim bytScore() As Byte = {12, 10, 16, 14, 8, 6, 9}
        Dim i As Short

        rtbOut.Clear()
        For i = bytScore.GetLowerBound(0) To bytScore.GetUpperBound(0)
            rtbOut.AppendText(bytScore(i).ToString & vbNewLine)
        Next i
        rtbOut.AppendText("Total items: " & bytScore.Length.ToString)

    End Sub
End Class
