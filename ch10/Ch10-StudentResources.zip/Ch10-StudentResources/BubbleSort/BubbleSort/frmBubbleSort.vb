Public Class frmBubbleSort

    Private Sub btnSort_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSort.Click
        Dim strColor() As String = {"Violet", "Indigo", "Blue", "Green", "Yellow", "Orange", "Red"}

        Dim i, j As Integer
        Dim strSwap As String

        'Clear and display original content
        rtbOut.Clear()
        rtbOut.AppendText("Unsorted: " & vbNewLine)

        For i = strColor.GetLowerBound(0) To strColor.GetUpperBound(0)
            rtbOut.AppendText(strColor(i) & ControlChars.NewLine)
        Next i

        For i = strColor.GetLowerBound(0) To strColor.GetUpperBound(0) - 1
            For j = strColor.GetLowerBound(0) To strColor.GetUpperBound(0) - 1
                If strColor(j) > strColor(j + 1) Then
                    strSwap = strColor(j)
                    strColor(j) = strColor(j + 1)
                    strColor(j + 1) = strSwap
                End If
            Next j
        Next i

        'Display sorted content
        rtbOut.AppendText(vbNewLine & "Sorted: " & vbNewLine)

        For i = strColor.GetLowerBound(0) To strColor.GetUpperBound(0)
            rtbOut.AppendText(strColor(i) & ControlChars.NewLine)
        Next i

    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        End
    End Sub
End Class
