'Prologue

Public Class frmTestScores
    Dim mintCount As Integer
    Dim mstrID() As String
    Dim mshoTest1() As Short
    Dim mshoTest2() As Short
    Dim mshoTest3() As Short
    Dim mshoTest4() As Short

    Private Sub btnLoad_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLoad.Click
        'Declarations
        Dim srdFile As System.IO.StreamReader
        Dim strFields() As String
        Dim strLine As String
        Dim strDetail As String

        'Input
        ofdTestScores.ShowDialog()
        srdFile = New System.IO.StreamReader(ofdTestScores.FileName)

        rtbOut.Clear()
        rtbOut.AppendText("         Student Test Scores" & vbNewLine & vbNewLine)
        rtbOut.AppendText("ID     Test1  Test2  Test3  Test4" & vbNewLine)

        Do While srdFile.Peek <> -1
            ReDim Preserve mstrID(mintCount)
            ReDim Preserve mshoTest1(mintCount)
            ReDim Preserve mshoTest2(mintCount)
            ReDim Preserve mshoTest3(mintCount)
            ReDim Preserve mshoTest4(mintCount)

            'Read
            strLine = srdFile.ReadLine()
            'Parse
            strFields = strLine.Split(",")

            mstrID(mintCount) = strFields(0)
            mshoTest1(mintCount) = strFields(1)
            mshoTest2(mintCount) = strFields(2)
            mshoTest3(mintCount) = strFields(3)
            mshoTest4(mintCount) = strFields(4)
            strDetail = mstrID(mintCount).PadRight(2) & _
            mshoTest1(mintCount).ToString("n0").PadLeft(7) & _
            mshoTest2(mintCount).ToString("n0").PadLeft(7) & _
            mshoTest3(mintCount).ToString("n0").PadLeft(7) & _
            mshoTest4(mintCount).ToString("n0").PadLeft(7) & _
            vbNewLine
            rtbOut.AppendText(strDetail)
            mintCount = mintCount + 1
        Loop

        'Close
        srdFile.Close()

    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        End

    End Sub

    Private Sub btnStudentAvg_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStudentAvg.Click
        Dim strDetail As String
        Dim i As Integer
        Dim shoStudTotal As Short
        Dim sngStudAverage As Single

        rtbOut.Clear()
        rtbOut.AppendText("Student  Average" & vbNewLine)
        For i = 0 To mintCount - 1
            shoStudTotal = mshoTest1(i) + mshoTest2(i) + mshoTest3(i) + mshoTest4(i)
            sngStudAverage = shoStudTotal / 4
            strDetail = mstrID(i).PadRight(10) & sngStudAverage.ToString("n1").PadLeft(6) & vbNewLine
            rtbOut.AppendText(strDetail)
        Next i

    End Sub


    Private Sub btnTestAvg_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTestAvg.Click
        Dim i As Integer
        Dim strDetail As String
        Dim intTotalTest1 As Integer
        Dim intTotalTest2 As Integer
        Dim intTotalTest3 As Integer
        Dim intTotalTest4 As Integer
        Dim sngAverageTest1 As Single
        Dim sngAverageTest2 As Single
        Dim sngAverageTest3 As Single
        Dim sngAverageTest4 As Single

        'Process Records
        For i = 0 To mintCount - 1
            intTotalTest1 = intTotalTest1 + mshoTest1(i)
            intTotalTest2 = intTotalTest2 + mshoTest2(i)
            intTotalTest3 = intTotalTest3 + mshoTest3(i)
            intTotalTest4 = intTotalTest4 + mshoTest4(i)
        Next i

        'Average
        sngAverageTest1 = intTotalTest1 / mintCount
        sngAverageTest2 = intTotalTest2 / mintCount
        sngAverageTest3 = intTotalTest3 / mintCount
        sngAverageTest4 = intTotalTest4 / mintCount

        'Output
        rtbOut.Clear()
        rtbOut.AppendText("      Test1  Test2  Test3  Test4" & vbNewLine)
        strDetail = "Avg." & sngAverageTest1.ToString("n1").PadLeft(7) & _
        sngAverageTest2.ToString("n1").PadLeft(7) & _
        sngAverageTest3.ToString("n1").PadLeft(7) & _
        sngAverageTest4.ToString("n1").PadLeft(7) & vbNewLine
        rtbOut.AppendText(strDetail)

    End Sub

    Private Sub btnHighScore_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHighScore.Click
        Dim strDetail As String
        Dim i As Integer
        Dim strHighScoreID(3) As String
        Dim bytHighScore(3) As Byte

        'Find High Scores
        For i = 0 To mintCount - 1
            If mshoTest1(i) > bytHighScore(0) Then
                bytHighScore(0) = mshoTest1(i)
                strHighScoreID(0) = mstrID(i)
            End If
            If mshoTest2(i) > bytHighScore(1) Then
                bytHighScore(1) = mshoTest2(i)
                strHighScoreID(1) = mstrID(i)
            End If
            If mshoTest3(i) > bytHighScore(2) Then
                bytHighScore(2) = mshoTest3(i)
                strHighScoreID(2) = mstrID(i)
            End If
            If mshoTest4(i) > bytHighScore(3) Then
                bytHighScore(3) = mshoTest4(i)
                strHighScoreID(3) = mstrID(i)
            End If
        Next i

        'High Score Output
        rtbOut.Clear()
        strDetail = "Test 1 High Score: " & strHighScoreID(0).PadRight(6) & _
        bytHighScore(0).ToString("n0").PadLeft(4) & vbNewLine
        rtbOut.AppendText(strDetail)
        strDetail = "Test 2 High Score: " & strHighScoreID(1).PadRight(6) & _
        bytHighScore(1).ToString("n0").PadLeft(4) & vbNewLine
        rtbOut.AppendText(strDetail)
        strDetail = "Test 3 High Score: " & strHighScoreID(2).PadRight(6) & _
        bytHighScore(2).ToString("n0").PadLeft(4) & vbNewLine
        rtbOut.AppendText(strDetail)
        strDetail = "Test 4 High Score: " & strHighScoreID(3).PadRight(6) & _
        bytHighScore(3).ToString("n0").PadLeft(4) & vbNewLine
        rtbOut.AppendText(strDetail)
    End Sub



















End Class
