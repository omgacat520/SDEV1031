﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtRollNumber = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.lblOut1 = New System.Windows.Forms.Label()
        Me.lblOut2 = New System.Windows.Forms.Label()
        Me.lblOut3 = New System.Windows.Forms.Label()
        Me.lblOut4 = New System.Windows.Forms.Label()
        Me.lblOut5 = New System.Windows.Forms.Label()
        Me.lblOut6 = New System.Windows.Forms.Label()
        Me.btnQuit = New System.Windows.Forms.Button()
        Me.btnRoll = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(90, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "How Many Rolls?"
        '
        'txtRollNumber
        '
        Me.txtRollNumber.Location = New System.Drawing.Point(108, 6)
        Me.txtRollNumber.Name = "txtRollNumber"
        Me.txtRollNumber.Size = New System.Drawing.Size(34, 20)
        Me.txtRollNumber.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(12, 44)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(46, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Rolled 1"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label3.Location = New System.Drawing.Point(12, 66)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(46, 13)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Rolled 2"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label4.Location = New System.Drawing.Point(12, 89)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(46, 13)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Rolled 3"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label5.Location = New System.Drawing.Point(12, 112)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(46, 13)
        Me.Label5.TabIndex = 5
        Me.Label5.Text = "Rolled 4"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label6.Location = New System.Drawing.Point(12, 136)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(46, 13)
        Me.Label6.TabIndex = 6
        Me.Label6.Text = "Rolled 5"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label7.Location = New System.Drawing.Point(12, 158)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(46, 13)
        Me.Label7.TabIndex = 7
        Me.Label7.Text = "Rolled 6"
        '
        'lblOut1
        '
        Me.lblOut1.AutoSize = True
        Me.lblOut1.Location = New System.Drawing.Point(64, 44)
        Me.lblOut1.Name = "lblOut1"
        Me.lblOut1.Size = New System.Drawing.Size(39, 13)
        Me.lblOut1.TabIndex = 8
        Me.lblOut1.Text = "Label8"
        Me.lblOut1.Visible = False
        '
        'lblOut2
        '
        Me.lblOut2.AutoSize = True
        Me.lblOut2.Location = New System.Drawing.Point(64, 66)
        Me.lblOut2.Name = "lblOut2"
        Me.lblOut2.Size = New System.Drawing.Size(39, 13)
        Me.lblOut2.TabIndex = 9
        Me.lblOut2.Text = "Label9"
        Me.lblOut2.Visible = False
        '
        'lblOut3
        '
        Me.lblOut3.AutoSize = True
        Me.lblOut3.Location = New System.Drawing.Point(64, 89)
        Me.lblOut3.Name = "lblOut3"
        Me.lblOut3.Size = New System.Drawing.Size(45, 13)
        Me.lblOut3.TabIndex = 10
        Me.lblOut3.Text = "Label10"
        Me.lblOut3.Visible = False
        '
        'lblOut4
        '
        Me.lblOut4.AutoSize = True
        Me.lblOut4.Location = New System.Drawing.Point(64, 112)
        Me.lblOut4.Name = "lblOut4"
        Me.lblOut4.Size = New System.Drawing.Size(45, 13)
        Me.lblOut4.TabIndex = 11
        Me.lblOut4.Text = "Label11"
        Me.lblOut4.Visible = False
        '
        'lblOut5
        '
        Me.lblOut5.AutoSize = True
        Me.lblOut5.Location = New System.Drawing.Point(64, 136)
        Me.lblOut5.Name = "lblOut5"
        Me.lblOut5.Size = New System.Drawing.Size(45, 13)
        Me.lblOut5.TabIndex = 12
        Me.lblOut5.Text = "Label12"
        Me.lblOut5.Visible = False
        '
        'lblOut6
        '
        Me.lblOut6.AutoSize = True
        Me.lblOut6.Location = New System.Drawing.Point(64, 158)
        Me.lblOut6.Name = "lblOut6"
        Me.lblOut6.Size = New System.Drawing.Size(45, 13)
        Me.lblOut6.TabIndex = 13
        Me.lblOut6.Text = "Label13"
        Me.lblOut6.Visible = False
        '
        'btnQuit
        '
        Me.btnQuit.Location = New System.Drawing.Point(160, 148)
        Me.btnQuit.Name = "btnQuit"
        Me.btnQuit.Size = New System.Drawing.Size(75, 23)
        Me.btnQuit.TabIndex = 14
        Me.btnQuit.Text = "Quit"
        Me.btnQuit.UseVisualStyleBackColor = True
        '
        'btnRoll
        '
        Me.btnRoll.Location = New System.Drawing.Point(160, 121)
        Me.btnRoll.Name = "btnRoll"
        Me.btnRoll.Size = New System.Drawing.Size(75, 23)
        Me.btnRoll.TabIndex = 15
        Me.btnRoll.Text = "Roll!"
        Me.btnRoll.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(245, 185)
        Me.Controls.Add(Me.btnRoll)
        Me.Controls.Add(Me.btnQuit)
        Me.Controls.Add(Me.lblOut6)
        Me.Controls.Add(Me.lblOut5)
        Me.Controls.Add(Me.lblOut4)
        Me.Controls.Add(Me.lblOut3)
        Me.Controls.Add(Me.lblOut2)
        Me.Controls.Add(Me.lblOut1)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtRollNumber)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Roll the dice!"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents txtRollNumber As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents lblOut1 As Label
    Friend WithEvents lblOut2 As Label
    Friend WithEvents lblOut3 As Label
    Friend WithEvents lblOut4 As Label
    Friend WithEvents lblOut5 As Label
    Friend WithEvents lblOut6 As Label
    Friend WithEvents btnQuit As Button
    Friend WithEvents btnRoll As Button
End Class
