'Prologue


Public Class frmFlying

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        End

    End Sub

    Private Sub btnBiplane_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBiplane.Click
        'Fly the biplane from left to right
 
    End Sub

    Private Sub btnPlaneII_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPlaneII.Click
        'Fly the plane from right to left
 
    End Sub

    Private Sub btnBalloon_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBalloon.Click
        'Make the balloon fly up
 
    End Sub

    Private Sub btnParachute_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnParachute.Click
        'Make the skydiver descend
    End Sub

    Private Sub btnKite_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnKite.Click
        'Make the kite start near the bottom right and end up at the top left

    End Sub

End Class
