<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmRockyRoadIceCreamStand
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.cboFlavor = New System.Windows.Forms.ComboBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.grpSize = New System.Windows.Forms.GroupBox
        Me.radBrainFreeze = New System.Windows.Forms.RadioButton
        Me.radLarge = New System.Windows.Forms.RadioButton
        Me.radMedium = New System.Windows.Forms.RadioButton
        Me.radSmall = New System.Windows.Forms.RadioButton
        Me.grpContainer = New System.Windows.Forms.GroupBox
        Me.radCup = New System.Windows.Forms.RadioButton
        Me.radDish = New System.Windows.Forms.RadioButton
        Me.radWaffleCone = New System.Windows.Forms.RadioButton
        Me.radSugarcone = New System.Windows.Forms.RadioButton
        Me.grpToppings = New System.Windows.Forms.GroupBox
        Me.chkWhippedCream = New System.Windows.Forms.CheckBox
        Me.chkNuts = New System.Windows.Forms.CheckBox
        Me.chkChocolate = New System.Windows.Forms.CheckBox
        Me.chkSprinkles = New System.Windows.Forms.CheckBox
        Me.ttpPrices = New System.Windows.Forms.ToolTip(Me.components)
        Me.rtbOut = New System.Windows.Forms.RichTextBox
        Me.btnExit = New System.Windows.Forms.Button
        Me.btnClear = New System.Windows.Forms.Button
        Me.grpSize.SuspendLayout()
        Me.grpContainer.SuspendLayout()
        Me.grpToppings.SuspendLayout()
        Me.SuspendLayout()
        '
        'cboFlavor
        '
        Me.cboFlavor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboFlavor.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboFlavor.FormattingEnabled = True
        Me.cboFlavor.Items.AddRange(New Object() {"Chocolate", "Vanilla", "Strawberry", "Butter Brickle", "Pistachio", "Bubble Gum", "Licorice", "Cherry Nut"})
        Me.cboFlavor.Location = New System.Drawing.Point(25, 44)
        Me.cboFlavor.Name = "cboFlavor"
        Me.cboFlavor.Size = New System.Drawing.Size(121, 28)
        Me.cboFlavor.TabIndex = 0
        Me.ttpPrices.SetToolTip(Me.cboFlavor, "Select Your Favorite Flavor")
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(25, 18)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(121, 23)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Flavor"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'grpSize
        '
        Me.grpSize.Controls.Add(Me.radBrainFreeze)
        Me.grpSize.Controls.Add(Me.radLarge)
        Me.grpSize.Controls.Add(Me.radMedium)
        Me.grpSize.Controls.Add(Me.radSmall)
        Me.grpSize.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpSize.Location = New System.Drawing.Point(12, 92)
        Me.grpSize.Name = "grpSize"
        Me.grpSize.Size = New System.Drawing.Size(136, 141)
        Me.grpSize.TabIndex = 2
        Me.grpSize.TabStop = False
        Me.grpSize.Text = "Size"
        '
        'radBrainFreeze
        '
        Me.radBrainFreeze.AutoSize = True
        Me.radBrainFreeze.Location = New System.Drawing.Point(11, 112)
        Me.radBrainFreeze.Name = "radBrainFreeze"
        Me.radBrainFreeze.Size = New System.Drawing.Size(118, 24)
        Me.radBrainFreeze.TabIndex = 3
        Me.radBrainFreeze.Text = "Brain Freeze"
        Me.ttpPrices.SetToolTip(Me.radBrainFreeze, "$5.95")
        Me.radBrainFreeze.UseVisualStyleBackColor = True
        '
        'radLarge
        '
        Me.radLarge.AutoSize = True
        Me.radLarge.Location = New System.Drawing.Point(11, 82)
        Me.radLarge.Name = "radLarge"
        Me.radLarge.Size = New System.Drawing.Size(68, 24)
        Me.radLarge.TabIndex = 2
        Me.radLarge.Text = "Large"
        Me.ttpPrices.SetToolTip(Me.radLarge, "$3.95")
        Me.radLarge.UseVisualStyleBackColor = True
        '
        'radMedium
        '
        Me.radMedium.AutoSize = True
        Me.radMedium.Location = New System.Drawing.Point(11, 52)
        Me.radMedium.Name = "radMedium"
        Me.radMedium.Size = New System.Drawing.Size(83, 24)
        Me.radMedium.TabIndex = 1
        Me.radMedium.Text = "Medium"
        Me.ttpPrices.SetToolTip(Me.radMedium, "$2.95")
        Me.radMedium.UseVisualStyleBackColor = True
        '
        'radSmall
        '
        Me.radSmall.AutoSize = True
        Me.radSmall.Location = New System.Drawing.Point(11, 22)
        Me.radSmall.Name = "radSmall"
        Me.radSmall.Size = New System.Drawing.Size(66, 24)
        Me.radSmall.TabIndex = 0
        Me.radSmall.Text = "Small"
        Me.ttpPrices.SetToolTip(Me.radSmall, "$1.95")
        Me.radSmall.UseVisualStyleBackColor = True
        '
        'grpContainer
        '
        Me.grpContainer.Controls.Add(Me.radCup)
        Me.grpContainer.Controls.Add(Me.radDish)
        Me.grpContainer.Controls.Add(Me.radWaffleCone)
        Me.grpContainer.Controls.Add(Me.radSugarcone)
        Me.grpContainer.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpContainer.Location = New System.Drawing.Point(164, 92)
        Me.grpContainer.Name = "grpContainer"
        Me.grpContainer.Size = New System.Drawing.Size(136, 141)
        Me.grpContainer.TabIndex = 4
        Me.grpContainer.TabStop = False
        Me.grpContainer.Text = "Container"
        '
        'radCup
        '
        Me.radCup.AutoSize = True
        Me.radCup.Location = New System.Drawing.Point(11, 112)
        Me.radCup.Name = "radCup"
        Me.radCup.Size = New System.Drawing.Size(56, 24)
        Me.radCup.TabIndex = 3
        Me.radCup.Text = "Cup"
        Me.ttpPrices.SetToolTip(Me.radCup, "No Charge")
        Me.radCup.UseVisualStyleBackColor = True
        '
        'radDish
        '
        Me.radDish.AutoSize = True
        Me.radDish.Location = New System.Drawing.Point(11, 82)
        Me.radDish.Name = "radDish"
        Me.radDish.Size = New System.Drawing.Size(59, 24)
        Me.radDish.TabIndex = 2
        Me.radDish.Text = "Dish"
        Me.ttpPrices.SetToolTip(Me.radDish, "No Charge")
        Me.radDish.UseVisualStyleBackColor = True
        '
        'radWaffleCone
        '
        Me.radWaffleCone.AutoSize = True
        Me.radWaffleCone.Location = New System.Drawing.Point(11, 52)
        Me.radWaffleCone.Name = "radWaffleCone"
        Me.radWaffleCone.Size = New System.Drawing.Size(115, 24)
        Me.radWaffleCone.TabIndex = 1
        Me.radWaffleCone.Text = "Waffle Cone"
        Me.ttpPrices.SetToolTip(Me.radWaffleCone, "Add $.25")
        Me.radWaffleCone.UseVisualStyleBackColor = True
        '
        'radSugarcone
        '
        Me.radSugarcone.AutoSize = True
        Me.radSugarcone.Location = New System.Drawing.Point(11, 22)
        Me.radSugarcone.Name = "radSugarcone"
        Me.radSugarcone.Size = New System.Drawing.Size(112, 24)
        Me.radSugarcone.TabIndex = 0
        Me.radSugarcone.Text = "Sugar Cone"
        Me.ttpPrices.SetToolTip(Me.radSugarcone, "Add $.25")
        Me.radSugarcone.UseVisualStyleBackColor = True
        '
        'grpToppings
        '
        Me.grpToppings.Controls.Add(Me.chkWhippedCream)
        Me.grpToppings.Controls.Add(Me.chkNuts)
        Me.grpToppings.Controls.Add(Me.chkChocolate)
        Me.grpToppings.Controls.Add(Me.chkSprinkles)
        Me.grpToppings.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpToppings.Location = New System.Drawing.Point(318, 92)
        Me.grpToppings.Name = "grpToppings"
        Me.grpToppings.Size = New System.Drawing.Size(157, 141)
        Me.grpToppings.TabIndex = 5
        Me.grpToppings.TabStop = False
        Me.grpToppings.Text = "Toppings"
        '
        'chkWhippedCream
        '
        Me.chkWhippedCream.Location = New System.Drawing.Point(6, 111)
        Me.chkWhippedCream.Name = "chkWhippedCream"
        Me.chkWhippedCream.Size = New System.Drawing.Size(145, 24)
        Me.chkWhippedCream.TabIndex = 3
        Me.chkWhippedCream.Text = "Whipped Cream"
        Me.ttpPrices.SetToolTip(Me.chkWhippedCream, "Add $.15 Each")
        Me.chkWhippedCream.UseVisualStyleBackColor = True
        '
        'chkNuts
        '
        Me.chkNuts.Location = New System.Drawing.Point(6, 82)
        Me.chkNuts.Name = "chkNuts"
        Me.chkNuts.Size = New System.Drawing.Size(93, 24)
        Me.chkNuts.TabIndex = 2
        Me.chkNuts.Text = "Nuts"
        Me.ttpPrices.SetToolTip(Me.chkNuts, "Add $.15 Each")
        Me.chkNuts.UseVisualStyleBackColor = True
        '
        'chkChocolate
        '
        Me.chkChocolate.Location = New System.Drawing.Point(5, 53)
        Me.chkChocolate.Name = "chkChocolate"
        Me.chkChocolate.Size = New System.Drawing.Size(100, 24)
        Me.chkChocolate.TabIndex = 1
        Me.chkChocolate.Text = "Chocolate"
        Me.ttpPrices.SetToolTip(Me.chkChocolate, "Add $.15 Each")
        Me.chkChocolate.UseVisualStyleBackColor = True
        '
        'chkSprinkles
        '
        Me.chkSprinkles.Location = New System.Drawing.Point(6, 22)
        Me.chkSprinkles.Name = "chkSprinkles"
        Me.chkSprinkles.Size = New System.Drawing.Size(100, 24)
        Me.chkSprinkles.TabIndex = 0
        Me.chkSprinkles.Text = "Sprinkles"
        Me.ttpPrices.SetToolTip(Me.chkSprinkles, "Add $.15 Each")
        Me.chkSprinkles.UseVisualStyleBackColor = True
        '
        'rtbOut
        '
        Me.rtbOut.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rtbOut.Location = New System.Drawing.Point(0, 265)
        Me.rtbOut.Name = "rtbOut"
        Me.rtbOut.Size = New System.Drawing.Size(500, 96)
        Me.rtbOut.TabIndex = 6
        Me.rtbOut.Text = ""
        '
        'btnExit
        '
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(400, 44)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 30)
        Me.btnExit.TabIndex = 7
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.Location = New System.Drawing.Point(292, 44)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 30)
        Me.btnClear.TabIndex = 8
        Me.btnClear.Text = "&Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'frmRockyRoadIceCreamStand
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(492, 373)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.rtbOut)
        Me.Controls.Add(Me.grpToppings)
        Me.Controls.Add(Me.grpContainer)
        Me.Controls.Add(Me.grpSize)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.cboFlavor)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmRockyRoadIceCreamStand"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Rocky Road Ice Cream Stand"
        Me.grpSize.ResumeLayout(False)
        Me.grpSize.PerformLayout()
        Me.grpContainer.ResumeLayout(False)
        Me.grpContainer.PerformLayout()
        Me.grpToppings.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents cboFlavor As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents grpSize As System.Windows.Forms.GroupBox
    Friend WithEvents radBrainFreeze As System.Windows.Forms.RadioButton
    Friend WithEvents radLarge As System.Windows.Forms.RadioButton
    Friend WithEvents radMedium As System.Windows.Forms.RadioButton
    Friend WithEvents radSmall As System.Windows.Forms.RadioButton
    Friend WithEvents grpContainer As System.Windows.Forms.GroupBox
    Friend WithEvents radCup As System.Windows.Forms.RadioButton
    Friend WithEvents radDish As System.Windows.Forms.RadioButton
    Friend WithEvents radWaffleCone As System.Windows.Forms.RadioButton
    Friend WithEvents radSugarcone As System.Windows.Forms.RadioButton
    Friend WithEvents grpToppings As System.Windows.Forms.GroupBox
    Friend WithEvents chkWhippedCream As System.Windows.Forms.CheckBox
    Friend WithEvents chkNuts As System.Windows.Forms.CheckBox
    Friend WithEvents chkChocolate As System.Windows.Forms.CheckBox
    Friend WithEvents chkSprinkles As System.Windows.Forms.CheckBox
    Friend WithEvents ttpPrices As System.Windows.Forms.ToolTip
    Friend WithEvents rtbOut As System.Windows.Forms.RichTextBox
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button

End Class
