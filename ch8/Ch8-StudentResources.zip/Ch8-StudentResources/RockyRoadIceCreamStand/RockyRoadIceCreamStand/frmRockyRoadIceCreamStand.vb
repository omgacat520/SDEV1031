'Prologue

Public Class frmRockyRoadIceCreamStand
    Const mdecSmall As Decimal = 1.95
    Const mdecMedium As Decimal = 2.95
    Const mdecLarge As Decimal = 3.95
    Const mdecBrainFreeze As Decimal = 5.95
    Const mdecCone As Decimal = 0.25
    Const mdecToppings As Decimal = 0.15

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        End

    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        'Clears settings and starts over
        radMedium.Checked = True
        radSugarcone.Checked = True
        chkSprinkles.Checked = False
        chkChocolate.Checked = False
        chkNuts.Checked = False
        chkWhippedCream.Checked = False
        cboFlavor.SelectedIndex = 1
        rtbOut.Clear()

    End Sub

    Private Sub CalcTotal()
        Dim decTotal As Decimal
        Dim strFlavor As String
        Dim strSize As String
        Dim strContainer As String
        Dim strToppings As String = "Toppings: "

        'Get flavor
        strFlavor = cboFlavor.Items(cboFlavor.SelectedIndex)

        'Get cone price and size
        If radSmall.Checked Then
            decTotal = mdecSmall
            strSize = "Small"
        ElseIf radMedium.Checked Then
            decTotal = mdecMedium
            strSize = "Medium"
        ElseIf radLarge.Checked Then
            decTotal = mdecLarge
            strSize = "Large"
        Else
            decTotal = mdecBrainFreeze
            strSize = "Brain Freeze"
        End If

        'Check to see if they want a cone
        If radSugarcone.Checked Then
            decTotal += mdecCone
            strContainer = "Sugar Cone"
        ElseIf radWaffleCone.Checked Then
            decTotal += mdecCone
            strContainer = "Waffle Cone"
        ElseIf radDish.Checked Then
            strContainer = "Dish"
        ElseIf radCup.Checked Then
            strContainer = "Cup"
        End If

        'Check for toppings
        If chkSprinkles.Checked Then
            decTotal += mdecToppings
            strToppings += "Sprinkles "
        End If
        If chkChocolate.Checked Then
            decTotal += mdecToppings
            strToppings += "Chocolate "
        End If
        If chkNuts.Checked Then
            decTotal += mdecToppings
            strToppings += "Nuts "
        End If
        If chkWhippedCream.Checked Then
            decTotal += mdecToppings
            strToppings += "Whipped Cream"
        End If

        'Output
        rtbOut.Clear()
        rtbOut.AppendText("Size          Flavor           Price" & vbNewLine)
        rtbOut.AppendText(strSize.PadRight(14) & strFlavor.PadRight(12) & decTotal.ToString("c").PadLeft(10) & vbNewLine)
        rtbOut.AppendText("Container: " & strContainer & vbNewLine)
        rtbOut.AppendText(strToppings)

    End Sub

    Private Sub radSmall_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radSmall.CheckedChanged
        Call CalcTotal()

    End Sub

    Private Sub radMedium_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radMedium.CheckedChanged
        Call CalcTotal()

    End Sub

    Private Sub radLarge_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radLarge.CheckedChanged
        Call CalcTotal()

    End Sub

    Private Sub radBrainFreeze_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radBrainFreeze.CheckedChanged
        Call CalcTotal()

    End Sub

    Private Sub radSugarcone_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radSugarcone.CheckedChanged
        Call CalcTotal()

    End Sub

    Private Sub radWaffleCone_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radWaffleCone.CheckedChanged
        Call CalcTotal()

    End Sub

    Private Sub radDish_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radDish.CheckedChanged
        Call CalcTotal()

    End Sub

    Private Sub radCup_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radCup.CheckedChanged
        Call CalcTotal()

    End Sub

    Private Sub chkSprinkles_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkSprinkles.CheckedChanged
        Call CalcTotal()

    End Sub

    Private Sub chkChocolate_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkChocolate.CheckedChanged
        Call CalcTotal()

    End Sub

    Private Sub chkNuts_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkNuts.CheckedChanged
        Call CalcTotal()

    End Sub

    Private Sub chkWhippedCream_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkWhippedCream.CheckedChanged
        Call CalcTotal()

    End Sub

    Private Sub frmRockyRoadIceCreamStand_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        cboFlavor.SelectedIndex = 1

    End Sub
End Class
