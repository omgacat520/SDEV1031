'Proglogue

Public Class frmNewControls

    Private Sub hsbFeet_Scroll(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ScrollEventArgs) Handles hsbFeet.Scroll
        Dim sngInches As Single
        Dim sngFeet As Single
        Dim sngYards As Single
        Dim sngMiles As Single

        'Input
        sngFeet = hsbFeet.Value

        'Processing
        sngInches = sngFeet * 12
        sngYards = sngFeet / 3
        sngMiles = sngFeet / 5280

        'Output
        lblInches.Text = sngInches.ToString("n0")
        lblFeet.Text = sngFeet.ToString("n0")
        lblYards.Text = sngYards.ToString("n2")
        lblMiles.Text = sngMiles.ToString("n2")

    End Sub

    Private Sub btnExitLinear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExitLinear.Click
        End

    End Sub

    Private Sub hsbGallons_Scroll(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ScrollEventArgs) Handles hsbGallons.Scroll
        Dim sngCups As Single
        Dim sngPints As Single
        Dim sngQuarts As Single
        Dim sngGallons As Single

        'Input
        sngGallons = hsbGallons.Value

        'Processing
        sngCups = sngGallons * 16
        sngPints = sngGallons * 8
        sngQuarts = sngGallons * 4

        'Output
        lblCups.Text = sngCups.ToString("n0")
        lblPints.Text = sngPints.ToString("n0")
        lblQuarts.Text = sngQuarts.ToString("n0")
        lblGallons.Text = sngGallons.ToString("n0")

    End Sub
    Private Sub btnExitLiquid_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExitLiquid.Click
        End

    End Sub


    Private Sub btnExitMetric_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExitMetric.Click
        End

    End Sub

    Private Sub trbMetric_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trbMetric.Scroll
        Dim sngCentimeter As Single
        Dim sngDecimeter As Single
        Dim sngMeter As Single
        Dim sngKilometer As Single

        'Input
        sngMeter = trbMetric.Value

        'Processing
        sngCentimeter = sngMeter * 100
        sngDecimeter = sngMeter * 10
        sngKilometer = sngMeter / 1000

        'Output
        lblCentimeter.Text = sngCentimeter.ToString("n0")
        lblDecimeter.Text = sngDecimeter.ToString("n0")
        lblMeter.Text = sngMeter.ToString("n0")
        lblKilometer.Text = sngKilometer.ToString("n2")
    End Sub

End Class
