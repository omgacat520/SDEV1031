<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmNewControls
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.tabMain = New System.Windows.Forms.TabControl
        Me.tabLinear = New System.Windows.Forms.TabPage
        Me.btnExitLinear = New System.Windows.Forms.Button
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.lblMiles = New System.Windows.Forms.Label
        Me.lblYards = New System.Windows.Forms.Label
        Me.lblInches = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.lblFeet = New System.Windows.Forms.Label
        Me.hsbFeet = New System.Windows.Forms.HScrollBar
        Me.tabLiquid = New System.Windows.Forms.TabPage
        Me.hsbGallons = New System.Windows.Forms.HScrollBar
        Me.btnExitLiquid = New System.Windows.Forms.Button
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.lblGallons = New System.Windows.Forms.Label
        Me.lblQuarts = New System.Windows.Forms.Label
        Me.lblCups = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.lblPints = New System.Windows.Forms.Label
        Me.tabMetric = New System.Windows.Forms.TabPage
        Me.trbMetric = New System.Windows.Forms.TrackBar
        Me.btnExitMetric = New System.Windows.Forms.Button
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.lblKilometer = New System.Windows.Forms.Label
        Me.lblMeter = New System.Windows.Forms.Label
        Me.lblCentimeter = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.lblDecimeter = New System.Windows.Forms.Label
        Me.tabMain.SuspendLayout()
        Me.tabLinear.SuspendLayout()
        Me.tabLiquid.SuspendLayout()
        Me.tabMetric.SuspendLayout()
        CType(Me.trbMetric, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'tabMain
        '
        Me.tabMain.Controls.Add(Me.tabLinear)
        Me.tabMain.Controls.Add(Me.tabLiquid)
        Me.tabMain.Controls.Add(Me.tabMetric)
        Me.tabMain.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tabMain.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tabMain.Location = New System.Drawing.Point(0, 0)
        Me.tabMain.Name = "tabMain"
        Me.tabMain.SelectedIndex = 0
        Me.tabMain.Size = New System.Drawing.Size(392, 373)
        Me.tabMain.TabIndex = 0
        '
        'tabLinear
        '
        Me.tabLinear.Controls.Add(Me.btnExitLinear)
        Me.tabLinear.Controls.Add(Me.Label4)
        Me.tabLinear.Controls.Add(Me.Label3)
        Me.tabLinear.Controls.Add(Me.Label2)
        Me.tabLinear.Controls.Add(Me.lblMiles)
        Me.tabLinear.Controls.Add(Me.lblYards)
        Me.tabLinear.Controls.Add(Me.lblInches)
        Me.tabLinear.Controls.Add(Me.Label1)
        Me.tabLinear.Controls.Add(Me.lblFeet)
        Me.tabLinear.Controls.Add(Me.hsbFeet)
        Me.tabLinear.Location = New System.Drawing.Point(4, 29)
        Me.tabLinear.Name = "tabLinear"
        Me.tabLinear.Padding = New System.Windows.Forms.Padding(3)
        Me.tabLinear.Size = New System.Drawing.Size(384, 340)
        Me.tabLinear.TabIndex = 0
        Me.tabLinear.Text = "Linear"
        Me.tabLinear.UseVisualStyleBackColor = True
        '
        'btnExitLinear
        '
        Me.btnExitLinear.Location = New System.Drawing.Point(301, 291)
        Me.btnExitLinear.Name = "btnExitLinear"
        Me.btnExitLinear.Size = New System.Drawing.Size(75, 30)
        Me.btnExitLinear.TabIndex = 10
        Me.btnExitLinear.Text = "E&xit"
        Me.btnExitLinear.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(212, 172)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(100, 23)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "Miles"
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(212, 124)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(100, 23)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "Yards"
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(212, 28)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(100, 23)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Inches"
        '
        'lblMiles
        '
        Me.lblMiles.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMiles.Location = New System.Drawing.Point(73, 172)
        Me.lblMiles.Name = "lblMiles"
        Me.lblMiles.Size = New System.Drawing.Size(100, 23)
        Me.lblMiles.TabIndex = 6
        Me.lblMiles.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblYards
        '
        Me.lblYards.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblYards.Location = New System.Drawing.Point(73, 124)
        Me.lblYards.Name = "lblYards"
        Me.lblYards.Size = New System.Drawing.Size(100, 23)
        Me.lblYards.TabIndex = 5
        Me.lblYards.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblInches
        '
        Me.lblInches.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInches.Location = New System.Drawing.Point(73, 28)
        Me.lblInches.Name = "lblInches"
        Me.lblInches.Size = New System.Drawing.Size(100, 23)
        Me.lblInches.TabIndex = 4
        Me.lblInches.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(212, 76)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(100, 23)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Feet"
        '
        'lblFeet
        '
        Me.lblFeet.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFeet.Location = New System.Drawing.Point(73, 76)
        Me.lblFeet.Name = "lblFeet"
        Me.lblFeet.Size = New System.Drawing.Size(100, 23)
        Me.lblFeet.TabIndex = 2
        Me.lblFeet.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'hsbFeet
        '
        Me.hsbFeet.Location = New System.Drawing.Point(11, 228)
        Me.hsbFeet.Maximum = 10000
        Me.hsbFeet.Name = "hsbFeet"
        Me.hsbFeet.Size = New System.Drawing.Size(365, 18)
        Me.hsbFeet.TabIndex = 1
        '
        'tabLiquid
        '
        Me.tabLiquid.Controls.Add(Me.hsbGallons)
        Me.tabLiquid.Controls.Add(Me.btnExitLiquid)
        Me.tabLiquid.Controls.Add(Me.Label5)
        Me.tabLiquid.Controls.Add(Me.Label6)
        Me.tabLiquid.Controls.Add(Me.Label7)
        Me.tabLiquid.Controls.Add(Me.lblGallons)
        Me.tabLiquid.Controls.Add(Me.lblQuarts)
        Me.tabLiquid.Controls.Add(Me.lblCups)
        Me.tabLiquid.Controls.Add(Me.Label11)
        Me.tabLiquid.Controls.Add(Me.lblPints)
        Me.tabLiquid.Location = New System.Drawing.Point(4, 29)
        Me.tabLiquid.Name = "tabLiquid"
        Me.tabLiquid.Padding = New System.Windows.Forms.Padding(3)
        Me.tabLiquid.Size = New System.Drawing.Size(384, 340)
        Me.tabLiquid.TabIndex = 1
        Me.tabLiquid.Text = "Liquid"
        Me.tabLiquid.UseVisualStyleBackColor = True
        '
        'hsbGallons
        '
        Me.hsbGallons.Location = New System.Drawing.Point(11, 228)
        Me.hsbGallons.Maximum = 1000
        Me.hsbGallons.Name = "hsbGallons"
        Me.hsbGallons.Size = New System.Drawing.Size(365, 18)
        Me.hsbGallons.TabIndex = 22
        '
        'btnExitLiquid
        '
        Me.btnExitLiquid.Location = New System.Drawing.Point(301, 291)
        Me.btnExitLiquid.Name = "btnExitLiquid"
        Me.btnExitLiquid.Size = New System.Drawing.Size(75, 30)
        Me.btnExitLiquid.TabIndex = 20
        Me.btnExitLiquid.Text = "E&xit"
        Me.btnExitLiquid.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(212, 172)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(100, 23)
        Me.Label5.TabIndex = 19
        Me.Label5.Text = "Gallons"
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(212, 124)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(100, 23)
        Me.Label6.TabIndex = 18
        Me.Label6.Text = "Quarts"
        '
        'Label7
        '
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(212, 28)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(100, 23)
        Me.Label7.TabIndex = 17
        Me.Label7.Text = "Cups"
        '
        'lblGallons
        '
        Me.lblGallons.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGallons.Location = New System.Drawing.Point(73, 172)
        Me.lblGallons.Name = "lblGallons"
        Me.lblGallons.Size = New System.Drawing.Size(100, 23)
        Me.lblGallons.TabIndex = 16
        Me.lblGallons.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblQuarts
        '
        Me.lblQuarts.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblQuarts.Location = New System.Drawing.Point(73, 124)
        Me.lblQuarts.Name = "lblQuarts"
        Me.lblQuarts.Size = New System.Drawing.Size(100, 23)
        Me.lblQuarts.TabIndex = 15
        Me.lblQuarts.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblCups
        '
        Me.lblCups.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCups.Location = New System.Drawing.Point(73, 28)
        Me.lblCups.Name = "lblCups"
        Me.lblCups.Size = New System.Drawing.Size(100, 23)
        Me.lblCups.TabIndex = 14
        Me.lblCups.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label11
        '
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(212, 76)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(100, 23)
        Me.Label11.TabIndex = 13
        Me.Label11.Text = "Pints"
        '
        'lblPints
        '
        Me.lblPints.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPints.Location = New System.Drawing.Point(73, 76)
        Me.lblPints.Name = "lblPints"
        Me.lblPints.Size = New System.Drawing.Size(100, 23)
        Me.lblPints.TabIndex = 12
        Me.lblPints.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'tabMetric
        '
        Me.tabMetric.Controls.Add(Me.trbMetric)
        Me.tabMetric.Controls.Add(Me.btnExitMetric)
        Me.tabMetric.Controls.Add(Me.Label8)
        Me.tabMetric.Controls.Add(Me.Label9)
        Me.tabMetric.Controls.Add(Me.Label10)
        Me.tabMetric.Controls.Add(Me.lblKilometer)
        Me.tabMetric.Controls.Add(Me.lblMeter)
        Me.tabMetric.Controls.Add(Me.lblCentimeter)
        Me.tabMetric.Controls.Add(Me.Label15)
        Me.tabMetric.Controls.Add(Me.lblDecimeter)
        Me.tabMetric.Location = New System.Drawing.Point(4, 29)
        Me.tabMetric.Name = "tabMetric"
        Me.tabMetric.Size = New System.Drawing.Size(384, 340)
        Me.tabMetric.TabIndex = 2
        Me.tabMetric.Text = "Metric"
        Me.tabMetric.UseVisualStyleBackColor = True
        '
        'trbMetric
        '
        Me.trbMetric.LargeChange = 10
        Me.trbMetric.Location = New System.Drawing.Point(11, 221)
        Me.trbMetric.Maximum = 10000
        Me.trbMetric.Name = "trbMetric"
        Me.trbMetric.Size = New System.Drawing.Size(365, 42)
        Me.trbMetric.TabIndex = 21
        Me.trbMetric.TickFrequency = 100
        '
        'btnExitMetric
        '
        Me.btnExitMetric.Location = New System.Drawing.Point(301, 291)
        Me.btnExitMetric.Name = "btnExitMetric"
        Me.btnExitMetric.Size = New System.Drawing.Size(75, 30)
        Me.btnExitMetric.TabIndex = 20
        Me.btnExitMetric.Text = "E&xit"
        Me.btnExitMetric.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(212, 172)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(100, 23)
        Me.Label8.TabIndex = 19
        Me.Label8.Text = "Kilometer"
        '
        'Label9
        '
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(212, 124)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(100, 23)
        Me.Label9.TabIndex = 18
        Me.Label9.Text = "Meter"
        '
        'Label10
        '
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(212, 28)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(100, 23)
        Me.Label10.TabIndex = 17
        Me.Label10.Text = "Centimeter"
        '
        'lblKilometer
        '
        Me.lblKilometer.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKilometer.Location = New System.Drawing.Point(73, 172)
        Me.lblKilometer.Name = "lblKilometer"
        Me.lblKilometer.Size = New System.Drawing.Size(100, 23)
        Me.lblKilometer.TabIndex = 16
        Me.lblKilometer.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblMeter
        '
        Me.lblMeter.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMeter.Location = New System.Drawing.Point(73, 124)
        Me.lblMeter.Name = "lblMeter"
        Me.lblMeter.Size = New System.Drawing.Size(100, 23)
        Me.lblMeter.TabIndex = 15
        Me.lblMeter.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblCentimeter
        '
        Me.lblCentimeter.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCentimeter.Location = New System.Drawing.Point(73, 28)
        Me.lblCentimeter.Name = "lblCentimeter"
        Me.lblCentimeter.Size = New System.Drawing.Size(100, 23)
        Me.lblCentimeter.TabIndex = 14
        Me.lblCentimeter.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label15
        '
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(212, 76)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(100, 23)
        Me.Label15.TabIndex = 13
        Me.Label15.Text = "Decimeter"
        '
        'lblDecimeter
        '
        Me.lblDecimeter.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDecimeter.Location = New System.Drawing.Point(73, 76)
        Me.lblDecimeter.Name = "lblDecimeter"
        Me.lblDecimeter.Size = New System.Drawing.Size(100, 23)
        Me.lblDecimeter.TabIndex = 12
        Me.lblDecimeter.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'frmNewControls
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(392, 373)
        Me.Controls.Add(Me.tabMain)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmNewControls"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Tab Controls - ScrollBars - TrackBars"
        Me.tabMain.ResumeLayout(False)
        Me.tabLinear.ResumeLayout(False)
        Me.tabLiquid.ResumeLayout(False)
        Me.tabMetric.ResumeLayout(False)
        Me.tabMetric.PerformLayout()
        CType(Me.trbMetric, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents tabMain As System.Windows.Forms.TabControl
    Friend WithEvents tabLinear As System.Windows.Forms.TabPage
    Friend WithEvents tabLiquid As System.Windows.Forms.TabPage
    Friend WithEvents tabMetric As System.Windows.Forms.TabPage
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents lblMiles As System.Windows.Forms.Label
    Friend WithEvents lblYards As System.Windows.Forms.Label
    Friend WithEvents lblInches As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblFeet As System.Windows.Forms.Label
    Friend WithEvents hsbFeet As System.Windows.Forms.HScrollBar
    Friend WithEvents btnExitLinear As System.Windows.Forms.Button
    Friend WithEvents btnExitLiquid As System.Windows.Forms.Button
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents lblGallons As System.Windows.Forms.Label
    Friend WithEvents lblQuarts As System.Windows.Forms.Label
    Friend WithEvents lblCups As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents lblPints As System.Windows.Forms.Label
    Friend WithEvents btnExitMetric As System.Windows.Forms.Button
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents lblKilometer As System.Windows.Forms.Label
    Friend WithEvents lblMeter As System.Windows.Forms.Label
    Friend WithEvents lblCentimeter As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents lblDecimeter As System.Windows.Forms.Label
    Friend WithEvents trbMetric As System.Windows.Forms.TrackBar
    Friend WithEvents hsbGallons As System.Windows.Forms.HScrollBar

End Class
