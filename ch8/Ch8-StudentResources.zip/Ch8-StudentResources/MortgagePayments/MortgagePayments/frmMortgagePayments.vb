'Prologue


Public Class frmMortgagePayments

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        End

    End Sub
    Private Sub Clear()
        rtbOut.Clear()
        rtbOut.AppendText("                    Corn Exchange Bank" & vbNewLine)
        rtbOut.AppendText("                 Home Mortgage Calculator" & vbNewLine & vbNewLine)
        rtbOut.AppendText("Principal       Rate    Years    Monthly       Total" & vbNewLine)

    End Sub
    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        Call Clear()

    End Sub

    Private Sub btnGo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGo.Click
        'Declarations
        Dim strPrincipal As String
        Dim decPrincipal As Decimal
        Dim sngRate As Single
        Dim bytYears As Byte
        Dim decMonthly As Decimal
        Dim decTotal As Decimal

        'Input
        'Remove $ and comma from input and put in numeric variable
        strPrincipal = mtbPrincipal.Text
        strPrincipal = strPrincipal.TrimStart("$")
        strPrincipal = strPrincipal.Remove(3, 1)
        decPrincipal = Convert.ToDecimal(strPrincipal)

        sngRate = lstRate.Items.Item(lstRate.SelectedIndex)
        sngRate = sngRate / 100

        'Determine which RadioButton is checked
        If rad10Year.Checked Then
            bytYears = 10
        ElseIf rad15Year.Checked Then
            bytYears = 15
        ElseIf rad20Year.Checked Then
            bytYears = 20
        Else
            bytYears = 30
        End If


        'Processing
        'Calculate monthly payment and total amount
        decMonthly = Math.Abs(Pmt(sngRate / 12, bytYears * 12, decPrincipal))
        decTotal = decMonthly * bytYears * 12

        'Output
        rtbOut.AppendText(decPrincipal.ToString("c0").PadRight(14) & sngRate.ToString("p2").PadLeft(7) & _
        bytYears.ToString.PadLeft(6) & decMonthly.ToString("c").PadLeft(13) & decTotal.ToString("c").PadLeft(15) & vbNewLine)

    End Sub

    Private Sub frmMortgagePayments_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call Clear()
        rad15Year.Checked = True
        lstRate.SelectedIndex = 3

    End Sub
End Class
