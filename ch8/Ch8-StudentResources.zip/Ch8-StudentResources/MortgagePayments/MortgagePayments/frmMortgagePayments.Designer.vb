<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMortgagePayments
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.picNote = New System.Windows.Forms.PictureBox
        Me.mtbPrincipal = New System.Windows.Forms.MaskedTextBox
        Me.grpTerm = New System.Windows.Forms.GroupBox
        Me.rad10Year = New System.Windows.Forms.RadioButton
        Me.rad15Year = New System.Windows.Forms.RadioButton
        Me.rad20Year = New System.Windows.Forms.RadioButton
        Me.rad30Year = New System.Windows.Forms.RadioButton
        Me.lstRate = New System.Windows.Forms.ListBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.rtbOut = New System.Windows.Forms.RichTextBox
        Me.btnGo = New System.Windows.Forms.Button
        Me.btnClear = New System.Windows.Forms.Button
        Me.btnExit = New System.Windows.Forms.Button
        CType(Me.picNote, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpTerm.SuspendLayout()
        Me.SuspendLayout()
        '
        'picNote
        '
        Me.picNote.Image = Global.MortgagesPayments.My.Resources.Resources.CEB
        Me.picNote.Location = New System.Drawing.Point(371, 11)
        Me.picNote.Name = "picNote"
        Me.picNote.Size = New System.Drawing.Size(209, 90)
        Me.picNote.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picNote.TabIndex = 0
        Me.picNote.TabStop = False
        '
        'mtbPrincipal
        '
        Me.mtbPrincipal.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mtbPrincipal.Location = New System.Drawing.Point(65, 37)
        Me.mtbPrincipal.Mask = "$###,###"
        Me.mtbPrincipal.Name = "mtbPrincipal"
        Me.mtbPrincipal.Size = New System.Drawing.Size(84, 26)
        Me.mtbPrincipal.TabIndex = 1
        Me.mtbPrincipal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'grpTerm
        '
        Me.grpTerm.Controls.Add(Me.rad30Year)
        Me.grpTerm.Controls.Add(Me.rad20Year)
        Me.grpTerm.Controls.Add(Me.rad15Year)
        Me.grpTerm.Controls.Add(Me.rad10Year)
        Me.grpTerm.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpTerm.Location = New System.Drawing.Point(219, 11)
        Me.grpTerm.Name = "grpTerm"
        Me.grpTerm.Size = New System.Drawing.Size(104, 150)
        Me.grpTerm.TabIndex = 2
        Me.grpTerm.TabStop = False
        Me.grpTerm.Text = "Term"
        '
        'rad10Year
        '
        Me.rad10Year.AutoSize = True
        Me.rad10Year.Location = New System.Drawing.Point(18, 25)
        Me.rad10Year.Name = "rad10Year"
        Me.rad10Year.Size = New System.Drawing.Size(84, 24)
        Me.rad10Year.TabIndex = 0
        Me.rad10Year.TabStop = True
        Me.rad10Year.Text = "10-Year"
        Me.rad10Year.UseVisualStyleBackColor = True
        '
        'rad15Year
        '
        Me.rad15Year.AutoSize = True
        Me.rad15Year.Location = New System.Drawing.Point(18, 55)
        Me.rad15Year.Name = "rad15Year"
        Me.rad15Year.Size = New System.Drawing.Size(84, 24)
        Me.rad15Year.TabIndex = 1
        Me.rad15Year.TabStop = True
        Me.rad15Year.Text = "15-Year"
        Me.rad15Year.UseVisualStyleBackColor = True
        '
        'rad20Year
        '
        Me.rad20Year.AutoSize = True
        Me.rad20Year.Location = New System.Drawing.Point(18, 85)
        Me.rad20Year.Name = "rad20Year"
        Me.rad20Year.Size = New System.Drawing.Size(84, 24)
        Me.rad20Year.TabIndex = 2
        Me.rad20Year.TabStop = True
        Me.rad20Year.Text = "20-Year"
        Me.rad20Year.UseVisualStyleBackColor = True
        '
        'rad30Year
        '
        Me.rad30Year.AutoSize = True
        Me.rad30Year.Location = New System.Drawing.Point(18, 115)
        Me.rad30Year.Name = "rad30Year"
        Me.rad30Year.Size = New System.Drawing.Size(84, 24)
        Me.rad30Year.TabIndex = 3
        Me.rad30Year.TabStop = True
        Me.rad30Year.Text = "30-Year"
        Me.rad30Year.UseVisualStyleBackColor = True
        '
        'lstRate
        '
        Me.lstRate.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstRate.FormattingEnabled = True
        Me.lstRate.ItemHeight = 20
        Me.lstRate.Items.AddRange(New Object() {"5.00", "5.25", "5.50", "5.75", "6.00", "6.25", "6.50", "6.75", "7.00"})
        Me.lstRate.Location = New System.Drawing.Point(65, 120)
        Me.lstRate.Name = "lstRate"
        Me.lstRate.Size = New System.Drawing.Size(84, 84)
        Me.lstRate.TabIndex = 3
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(49, 11)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(100, 23)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Principal"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(40, 94)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(109, 23)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Interest Rate"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'rtbOut
        '
        Me.rtbOut.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.rtbOut.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rtbOut.Location = New System.Drawing.Point(0, 229)
        Me.rtbOut.Name = "rtbOut"
        Me.rtbOut.Size = New System.Drawing.Size(592, 244)
        Me.rtbOut.TabIndex = 6
        Me.rtbOut.Text = ""
        '
        'btnGo
        '
        Me.btnGo.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnGo.Location = New System.Drawing.Point(371, 125)
        Me.btnGo.Name = "btnGo"
        Me.btnGo.Size = New System.Drawing.Size(75, 30)
        Me.btnGo.TabIndex = 7
        Me.btnGo.Text = "&Go!"
        Me.btnGo.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.Location = New System.Drawing.Point(371, 170)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 30)
        Me.btnClear.TabIndex = 8
        Me.btnClear.Text = "&Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(493, 170)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 30)
        Me.btnExit.TabIndex = 9
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'frmMortgagePayments
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(592, 473)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnGo)
        Me.Controls.Add(Me.rtbOut)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lstRate)
        Me.Controls.Add(Me.grpTerm)
        Me.Controls.Add(Me.mtbPrincipal)
        Me.Controls.Add(Me.picNote)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmMortgagePayments"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Corn Exchange Bank -- We'll Treat Your Money Like It Was Our Own!"
        CType(Me.picNote, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpTerm.ResumeLayout(False)
        Me.grpTerm.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents picNote As System.Windows.Forms.PictureBox
    Friend WithEvents mtbPrincipal As System.Windows.Forms.MaskedTextBox
    Friend WithEvents grpTerm As System.Windows.Forms.GroupBox
    Friend WithEvents rad30Year As System.Windows.Forms.RadioButton
    Friend WithEvents rad20Year As System.Windows.Forms.RadioButton
    Friend WithEvents rad15Year As System.Windows.Forms.RadioButton
    Friend WithEvents rad10Year As System.Windows.Forms.RadioButton
    Friend WithEvents lstRate As System.Windows.Forms.ListBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents rtbOut As System.Windows.Forms.RichTextBox
    Friend WithEvents btnGo As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button

End Class
