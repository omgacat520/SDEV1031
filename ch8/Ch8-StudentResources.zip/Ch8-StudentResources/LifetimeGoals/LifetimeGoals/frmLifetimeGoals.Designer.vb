<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmLifetimeGoals
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.clbGoals = New System.Windows.Forms.CheckedListBox
        Me.rtbMet = New System.Windows.Forms.RichTextBox
        Me.rtbYet = New System.Windows.Forms.RichTextBox
        Me.btnUpdate = New System.Windows.Forms.Button
        Me.btnExit = New System.Windows.Forms.Button
        Me.btnAdd = New System.Windows.Forms.Button
        Me.txtAdd = New System.Windows.Forms.TextBox
        Me.SuspendLayout()
        '
        'clbGoals
        '
        Me.clbGoals.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.clbGoals.FormattingEnabled = True
        Me.clbGoals.Items.AddRange(New Object() {"Get degree", "Write a book", "Visit all 50 States", "See the World Series", "Meet Neil Armstrong", "Visit Washington, D.C.", "Pick my 100 favorite songs", "Dandle great-grandchildren on my knee"})
        Me.clbGoals.Location = New System.Drawing.Point(12, 27)
        Me.clbGoals.Name = "clbGoals"
        Me.clbGoals.Size = New System.Drawing.Size(291, 130)
        Me.clbGoals.TabIndex = 4
        '
        'rtbMet
        '
        Me.rtbMet.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rtbMet.Location = New System.Drawing.Point(12, 178)
        Me.rtbMet.Name = "rtbMet"
        Me.rtbMet.Size = New System.Drawing.Size(325, 183)
        Me.rtbMet.TabIndex = 5
        Me.rtbMet.Text = ""
        '
        'rtbYet
        '
        Me.rtbYet.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rtbYet.Location = New System.Drawing.Point(355, 178)
        Me.rtbYet.Name = "rtbYet"
        Me.rtbYet.Size = New System.Drawing.Size(325, 183)
        Me.rtbYet.TabIndex = 6
        Me.rtbYet.Text = ""
        '
        'btnUpdate
        '
        Me.btnUpdate.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUpdate.Location = New System.Drawing.Point(461, 79)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(75, 30)
        Me.btnUpdate.TabIndex = 2
        Me.btnUpdate.Text = "&Update"
        Me.btnUpdate.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(591, 79)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 30)
        Me.btnExit.TabIndex = 3
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnAdd
        '
        Me.btnAdd.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAdd.Location = New System.Drawing.Point(331, 79)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(75, 30)
        Me.btnAdd.TabIndex = 1
        Me.btnAdd.Text = "&Add"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'txtAdd
        '
        Me.txtAdd.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAdd.Location = New System.Drawing.Point(331, 27)
        Me.txtAdd.Name = "txtAdd"
        Me.txtAdd.Size = New System.Drawing.Size(335, 26)
        Me.txtAdd.TabIndex = 0
        '
        'frmLifetimeGoals
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(692, 373)
        Me.Controls.Add(Me.txtAdd)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnUpdate)
        Me.Controls.Add(Me.rtbYet)
        Me.Controls.Add(Me.rtbMet)
        Me.Controls.Add(Me.clbGoals)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmLifetimeGoals"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Lifetime Goals"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents clbGoals As System.Windows.Forms.CheckedListBox
    Friend WithEvents rtbMet As System.Windows.Forms.RichTextBox
    Friend WithEvents rtbYet As System.Windows.Forms.RichTextBox
    Friend WithEvents btnUpdate As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents btnAdd As System.Windows.Forms.Button
    Friend WithEvents txtAdd As System.Windows.Forms.TextBox

End Class
