'Prologue

Public Class frmLifetimeGoals

    Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        Dim i As Integer
        Dim shoCount As Short

        'Find number of items and highest item number
        shoCount = clbGoals.Items.Count - 1

        'Clear RichTextBoxes
        rtbMet.Clear()
        rtbMet.AppendText("Done" & vbNewLine)
        rtbYet.Clear()
        rtbYet.AppendText("To Do" & vbNewLine)

        For i = 0 To shoCount
            If clbGoals.GetItemChecked(i) Then
                rtbMet.AppendText(clbGoals.Items.Item(i) & vbNewLine)
            Else
                rtbYet.AppendText(clbGoals.Items.Item(i) & vbNewLine)
            End If
        Next i

    End Sub

    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        'Add items to list

        Dim strAdd As String

        strAdd = txtAdd.Text
        clbGoals.Items.Add(strAdd)

    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        End

    End Sub
End Class
