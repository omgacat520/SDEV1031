Public Class frmOwtPizza
    Dim mstrSize As String
    Dim mdecPrice As Decimal
    Dim mdecTotal As Decimal
    Dim mstrStyle As String

    Private Sub radSmall_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radSmall.CheckedChanged
        mstrSize = "Small"
        mdecPrice = 8.95

    End Sub

    Private Sub radMedium_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radMedium.CheckedChanged
        mstrSize = "Medium"
        mdecPrice = 10.95

    End Sub

    Private Sub radLarge_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radLarge.CheckedChanged
        mstrSize = "Large"
        mdecPrice = 12.95

    End Sub

    Private Sub radManholeCover_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radManholeCover.CheckedChanged
        mstrSize = "Manhole Cover"
        mdecPrice = 14.95

    End Sub

    Private Sub btnOrder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOrder.Click
        rtbOut.AppendText("1" & ControlChars.Tab & mstrStyle & ControlChars.Tab & mstrSize & ControlChars.Tab & ControlChars.Tab & ControlChars.Tab & mdecPrice.ToString("c") & vbNewLine)

        mdecTotal += mdecPrice

    End Sub

    Private Sub PrintHeading()
        rtbOut.Clear()
        rtbOut.AppendText("                     Owt Pizza" & vbNewLine)
        rtbOut.AppendText("            Dine-in Carryout Delivery" & vbNewLine & vbNewLine)
    End Sub

    Private Sub frmOwtPizza_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        PrintHeading()

    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        End

    End Sub

    Private Sub radThin_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radThin.CheckedChanged
        mstrStyle = "Thin"

    End Sub

    Private Sub radThick_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radThick.CheckedChanged
        mstrStyle = "Thick"

    End Sub

    Private Sub radStuffed_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radStuffed.CheckedChanged
        mstrStyle = "Stuffed"

    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        mdecTotal = 0
        rtbOut.Clear()
        radMedium.Checked = True
        radThick.Checked = True

    End Sub
End Class
