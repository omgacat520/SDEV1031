<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmOwtPizza
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grpSize = New System.Windows.Forms.GroupBox
        Me.radManholeCover = New System.Windows.Forms.RadioButton
        Me.radLarge = New System.Windows.Forms.RadioButton
        Me.radMedium = New System.Windows.Forms.RadioButton
        Me.radSmall = New System.Windows.Forms.RadioButton
        Me.rtbOut = New System.Windows.Forms.RichTextBox
        Me.btnOrder = New System.Windows.Forms.Button
        Me.btnTotal = New System.Windows.Forms.Button
        Me.btnClear = New System.Windows.Forms.Button
        Me.btnExit = New System.Windows.Forms.Button
        Me.grpStyle = New System.Windows.Forms.GroupBox
        Me.radStuffed = New System.Windows.Forms.RadioButton
        Me.radThick = New System.Windows.Forms.RadioButton
        Me.radThin = New System.Windows.Forms.RadioButton
        Me.grpSize.SuspendLayout()
        Me.grpStyle.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpSize
        '
        Me.grpSize.Controls.Add(Me.radManholeCover)
        Me.grpSize.Controls.Add(Me.radLarge)
        Me.grpSize.Controls.Add(Me.radMedium)
        Me.grpSize.Controls.Add(Me.radSmall)
        Me.grpSize.Location = New System.Drawing.Point(12, 12)
        Me.grpSize.Name = "grpSize"
        Me.grpSize.Size = New System.Drawing.Size(125, 145)
        Me.grpSize.TabIndex = 4
        Me.grpSize.TabStop = False
        Me.grpSize.Text = "Size"
        '
        'radManholeCover
        '
        Me.radManholeCover.Location = New System.Drawing.Point(24, 110)
        Me.radManholeCover.Name = "radManholeCover"
        Me.radManholeCover.Size = New System.Drawing.Size(97, 24)
        Me.radManholeCover.TabIndex = 3
        Me.radManholeCover.Text = "Manhole Cover"
        '
        'radLarge
        '
        Me.radLarge.Location = New System.Drawing.Point(24, 80)
        Me.radLarge.Name = "radLarge"
        Me.radLarge.Size = New System.Drawing.Size(97, 24)
        Me.radLarge.TabIndex = 2
        Me.radLarge.Text = "Large"
        '
        'radMedium
        '
        Me.radMedium.Checked = True
        Me.radMedium.Location = New System.Drawing.Point(24, 48)
        Me.radMedium.Name = "radMedium"
        Me.radMedium.Size = New System.Drawing.Size(97, 24)
        Me.radMedium.TabIndex = 1
        Me.radMedium.TabStop = True
        Me.radMedium.Text = "Medium"
        '
        'radSmall
        '
        Me.radSmall.Location = New System.Drawing.Point(24, 16)
        Me.radSmall.Name = "radSmall"
        Me.radSmall.Size = New System.Drawing.Size(97, 24)
        Me.radSmall.TabIndex = 0
        Me.radSmall.Text = "Small"
        '
        'rtbOut
        '
        Me.rtbOut.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.rtbOut.Font = New System.Drawing.Font("Courier New", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rtbOut.Location = New System.Drawing.Point(0, 310)
        Me.rtbOut.Name = "rtbOut"
        Me.rtbOut.Size = New System.Drawing.Size(392, 157)
        Me.rtbOut.TabIndex = 5
        Me.rtbOut.Text = ""
        '
        'btnOrder
        '
        Me.btnOrder.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOrder.Location = New System.Drawing.Point(11, 261)
        Me.btnOrder.Name = "btnOrder"
        Me.btnOrder.Size = New System.Drawing.Size(75, 30)
        Me.btnOrder.TabIndex = 6
        Me.btnOrder.Text = "&Order"
        Me.btnOrder.UseVisualStyleBackColor = True
        '
        'btnTotal
        '
        Me.btnTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTotal.Location = New System.Drawing.Point(109, 261)
        Me.btnTotal.Name = "btnTotal"
        Me.btnTotal.Size = New System.Drawing.Size(75, 30)
        Me.btnTotal.TabIndex = 7
        Me.btnTotal.Text = "&Total"
        Me.btnTotal.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.Location = New System.Drawing.Point(207, 261)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 30)
        Me.btnClear.TabIndex = 8
        Me.btnClear.Text = "&Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(305, 261)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 30)
        Me.btnExit.TabIndex = 9
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'grpStyle
        '
        Me.grpStyle.Controls.Add(Me.radStuffed)
        Me.grpStyle.Controls.Add(Me.radThick)
        Me.grpStyle.Controls.Add(Me.radThin)
        Me.grpStyle.Location = New System.Drawing.Point(143, 12)
        Me.grpStyle.Name = "grpStyle"
        Me.grpStyle.Size = New System.Drawing.Size(96, 112)
        Me.grpStyle.TabIndex = 10
        Me.grpStyle.TabStop = False
        Me.grpStyle.Text = "Style"
        '
        'radStuffed
        '
        Me.radStuffed.Location = New System.Drawing.Point(24, 80)
        Me.radStuffed.Name = "radStuffed"
        Me.radStuffed.Size = New System.Drawing.Size(64, 24)
        Me.radStuffed.TabIndex = 2
        Me.radStuffed.Text = "Stuffed"
        '
        'radThick
        '
        Me.radThick.Checked = True
        Me.radThick.Location = New System.Drawing.Point(24, 48)
        Me.radThick.Name = "radThick"
        Me.radThick.Size = New System.Drawing.Size(64, 24)
        Me.radThick.TabIndex = 1
        Me.radThick.TabStop = True
        Me.radThick.Text = "Thick"
        '
        'radThin
        '
        Me.radThin.Location = New System.Drawing.Point(24, 16)
        Me.radThin.Name = "radThin"
        Me.radThin.Size = New System.Drawing.Size(64, 24)
        Me.radThin.TabIndex = 0
        Me.radThin.Text = "Thin"
        '
        'frmOwtPizza
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(392, 467)
        Me.Controls.Add(Me.grpStyle)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnTotal)
        Me.Controls.Add(Me.btnOrder)
        Me.Controls.Add(Me.rtbOut)
        Me.Controls.Add(Me.grpSize)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmOwtPizza"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Owt Pizza -- Warren and Carrie Owt Owners"
        Me.grpSize.ResumeLayout(False)
        Me.grpStyle.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents grpSize As System.Windows.Forms.GroupBox
    Friend WithEvents radManholeCover As System.Windows.Forms.RadioButton
    Friend WithEvents radLarge As System.Windows.Forms.RadioButton
    Friend WithEvents radMedium As System.Windows.Forms.RadioButton
    Friend WithEvents radSmall As System.Windows.Forms.RadioButton
    Friend WithEvents rtbOut As System.Windows.Forms.RichTextBox
    Friend WithEvents btnOrder As System.Windows.Forms.Button
    Friend WithEvents btnTotal As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents grpStyle As System.Windows.Forms.GroupBox
    Friend WithEvents radStuffed As System.Windows.Forms.RadioButton
    Friend WithEvents radThick As System.Windows.Forms.RadioButton
    Friend WithEvents radThin As System.Windows.Forms.RadioButton

End Class
