Public Class frmADayAtTheBeach

   
    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        Dim strFavorite As String
        Dim i As Integer
        Dim shoCount As Short
        Dim blnFound As Boolean

        strFavorite = cboBeachSupplies.Text
        shoCount = cboBeachSupplies.Items.Count
        shoCount = shoCount - 1

        For i = 0 To shoCount
            If strFavorite.ToUpper = cboBeachSupplies.Items.Item(i).ToUpper Then
                blnFound = True
            End If
        Next i
        If Not blnFound Then
            cboBeachSupplies.Items.Add(strFavorite)
        End If

    End Sub

    Private Sub btnRemove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRemove.Click
        Dim shoItemNum As Short

        shoItemNum = cboBeachSupplies.SelectedIndex

        If shoItemNum = -1 Then
            MsgBox("Please select an item from the list.", MsgBoxStyle.OkOnly, "Oops!")
        Else
            cboBeachSupplies.Items.Remove(cboBeachSupplies.Items.Item(shoItemNum))
        End If

        If cboBeachSupplies.Items.Count = -1 Then
            btnRemove.Enabled = False
        End If

    End Sub

    Private Sub cboBeachSupplies_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboBeachSupplies.TextChanged
        If cboBeachSupplies.Text <> "" Then
            btnAdd.Enabled = True
        Else
            btnAdd.Enabled = False
        End If
    End Sub

    Private Sub btnSort_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSort.Click
        cboBeachSupplies.Sorted = True

    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        End

    End Sub

End Class
