'Prologue


Public Class frmVBMasterTShirts
    Dim mstrSize As String
    Dim mdecPrice As Decimal

    Private Sub radSmall_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radSmall.CheckedChanged
        mstrSize = "Small"
        mdecPrice = 8

    End Sub

    Private Sub radMedium_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radMedium.CheckedChanged
        mstrSize = "Medium"
        mdecPrice = 8

    End Sub

    Private Sub radLarge_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radLarge.CheckedChanged
        mstrSize = "Large"
        mdecPrice = 10

    End Sub

    Private Sub radExtraLarge_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radExtraLarge.CheckedChanged
        mstrSize = "Extra Large"
        mdecPrice = 10

    End Sub

    Private Sub radXXL_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radXXL.CheckedChanged
        mstrSize = "XXL"
        mdecPrice = 12

    End Sub

    Private Sub btnOrder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOrder.Click
        lblSize.Text = mstrSize
        lblPrice.Text = mdecPrice.ToString("c")

    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        End

    End Sub

End Class
