'Prologue


Public Class frmMain

    Private Sub mnuFileExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFileExit.Click
        End
    End Sub

    Private Sub mnuHelpAbout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuHelpAbout.Click
        'Display About form
        Dim frmAbout As New frmAbout
        Me.Hide()
        frmAbout.Show()

    End Sub

    Private Sub mnuHelpHelp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuHelpHelp.Click
        'Display Help form
        Dim frmHelp As New frmHelp
        Me.Hide()
        frmHelp.Show()

    End Sub
End Class
