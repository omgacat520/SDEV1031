Public Class frmIDGenerator
    Dim mdatToday As Date

    Private Sub frmIDGenerator_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Find and Display today's date
        mdatToday = Now
        lblToday.Text = mdatToday.ToShortDateString

    End Sub

    Private Sub btnGenerate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGenerate.Click
        'Declarations
        Dim strLast As String
        Dim strFirst As String
        Dim strMiddle As String
        Dim strDept As String
        Dim intNum As Integer
        Dim strChar As String
        Dim strDate As String
        Dim bytChar As Byte
        Dim strTemp As String
        Dim strID As String
        Dim strLogin As String
        Dim strPassword As String

        'Input
        strLast = txtLast.Text
        strFirst = txtFirst.Text
        strMiddle = txtMiddle.Text
        strDept = cboDept.SelectedItem

        strDate = mdatToday.Day.ToString
        If strDate.Length < 2 Then
            strDate = "0" & strDate
        End If

        intNum = Int(Rnd() * 8999 + 1000)

        bytChar = Int(Rnd() * 26 + 65)

        'Processing
        'Get ID: LllFDeptnnnn
        'Where L is last name, F is first name Dept is Dept. 
        'and nnnn is a random number
        'Gather characters as needed in strTemp and append to strID
        strID = strLast.Substring(0, 1).ToUpper
        strTemp = strLast.Substring(1, 2).ToLower
        strID = strID & strTemp
        strTemp = strFirst.Substring(0, 1).ToUpper
        strID = strID & strTemp
        strTemp = strDept.Substring(0, 4)
        strID = strID & strTemp
        strTemp = intNum.ToString
        strID = strID & strTemp

        'Get Login: LfMnncdd
        'Where L is last name, f is first name, M is middle name,
        ' nn is number, C is a character and dd is the date
        strLogin = strLast.Substring(0, 1).ToUpper
        strTemp = strFirst.Substring(0, 1).ToLower
        strLogin = strLogin & strTemp
        strTemp = strMiddle.Substring(0, 1).ToUpper
        strLogin = strLogin & strTemp

        intNum = Int(Rnd() * 89 + 10)
        strTemp = intNum.ToString
        strLogin = strLogin & strTemp
        strTemp = Chr(bytChar)
        strLogin = strLogin & strTemp
        strLogin = strLogin & strDate

        'Get Password: cCnnclMf
        'Where c is a character, nn is a number, l is last name,
        'M is middle name and f is first name
        bytChar = Int(Rnd() * 26 + 65)
        strPassword = Chr(bytChar)
        bytChar = Int(Rnd() * 26 + 97)
        strTemp = Chr(bytChar)
        strPassword = strPassword & strTemp
        intNum = Int(Rnd() * 89 + 10)
        strTemp = intNum.ToString
        strPassword = strPassword & strTemp
        bytChar = Int(Rnd() * 26 + 97)
        strTemp = Chr(bytChar)
        strPassword = strPassword & strTemp
        strTemp = strLast.Substring(0, 1).ToLower
        strPassword = strPassword & strTemp
        strTemp = strMiddle.Substring(0, 1).ToUpper
        strPassword = strPassword & strTemp
        strTemp = strFirst.Substring(0, 1).ToLower
        strPassword = strPassword & strTemp

        'Output
        lblID.Text = strID
        lblLogin.Text = strLogin
        lblPassword.Text = strPassword


    End Sub
    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        End

    End Sub

End Class
