'Prologue

Public Class frmToDoList

    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        Dim strFavorite As String

        strFavorite = txtFavorite.Text
        If strFavorite = "" Then
            MsgBox("Please enter your item in the TextBox.", MsgBoxStyle.OkOnly, "Oops!")
        Else
            lstToDo.Items.Add(strFavorite)
            btnRemove.Enabled = True
        End If

    End Sub

    Private Sub btnRemove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRemove.Click
        Dim shoItemNum As Short
        shoItemNum = lstToDo.SelectedIndex
        If shoItemNum = -1 Then
            MsgBox("Please select an item from the list.", MsgBoxStyle.OkOnly, "Oops!")
        Else
            If shoItemNum >= 0 Then
                lstToDo.Items.Remove(lstToDo.SelectedItem)
            End If
        End If

        If lstToDo.Items.Count <= 0 Then
            btnRemove.Enabled = False
        End If
    End Sub

    Private Sub btnDisplay_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDisplay.Click
        Dim strDisplay As String
        Dim shoItemNum As Short

        shoItemNum = lstToDo.SelectedIndex

        If shoItemNum = -1 Then
            MsgBox("Please select an item from the list.", MsgBoxStyle.OkOnly, "Oops!")
        Else
            strDisplay = lstToDo.SelectedItem
            lblDisplay.Text = strDisplay
        End If
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        End

    End Sub
End Class
