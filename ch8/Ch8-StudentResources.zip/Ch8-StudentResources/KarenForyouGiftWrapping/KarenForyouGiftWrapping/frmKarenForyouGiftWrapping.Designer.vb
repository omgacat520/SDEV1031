<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmKarenForyouGiftWrapping
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grpSize = New System.Windows.Forms.GroupBox
        Me.radLarge = New System.Windows.Forms.RadioButton
        Me.radMedium = New System.Windows.Forms.RadioButton
        Me.radSmall = New System.Windows.Forms.RadioButton
        Me.grpAmenities = New System.Windows.Forms.GroupBox
        Me.chkCard = New System.Windows.Forms.CheckBox
        Me.chkRibbon = New System.Windows.Forms.CheckBox
        Me.chkBow = New System.Windows.Forms.CheckBox
        Me.lblTotal = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.btnExit = New System.Windows.Forms.Button
        Me.Label2 = New System.Windows.Forms.Label
        Me.grpSize.SuspendLayout()
        Me.grpAmenities.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpSize
        '
        Me.grpSize.Controls.Add(Me.radLarge)
        Me.grpSize.Controls.Add(Me.radMedium)
        Me.grpSize.Controls.Add(Me.radSmall)
        Me.grpSize.Location = New System.Drawing.Point(38, 46)
        Me.grpSize.Name = "grpSize"
        Me.grpSize.Size = New System.Drawing.Size(84, 118)
        Me.grpSize.TabIndex = 0
        Me.grpSize.TabStop = False
        Me.grpSize.Text = "Size"
        '
        'radLarge
        '
        Me.radLarge.AutoSize = True
        Me.radLarge.Location = New System.Drawing.Point(12, 84)
        Me.radLarge.Name = "radLarge"
        Me.radLarge.Size = New System.Drawing.Size(52, 17)
        Me.radLarge.TabIndex = 2
        Me.radLarge.TabStop = True
        Me.radLarge.Text = "Large"
        Me.radLarge.UseVisualStyleBackColor = True
        '
        'radMedium
        '
        Me.radMedium.AutoSize = True
        Me.radMedium.Location = New System.Drawing.Point(12, 51)
        Me.radMedium.Name = "radMedium"
        Me.radMedium.Size = New System.Drawing.Size(62, 17)
        Me.radMedium.TabIndex = 1
        Me.radMedium.TabStop = True
        Me.radMedium.Text = "Medium"
        Me.radMedium.UseVisualStyleBackColor = True
        '
        'radSmall
        '
        Me.radSmall.AutoSize = True
        Me.radSmall.Checked = True
        Me.radSmall.Location = New System.Drawing.Point(12, 19)
        Me.radSmall.Name = "radSmall"
        Me.radSmall.Size = New System.Drawing.Size(50, 17)
        Me.radSmall.TabIndex = 0
        Me.radSmall.TabStop = True
        Me.radSmall.Text = "Small"
        Me.radSmall.UseVisualStyleBackColor = True
        '
        'grpAmenities
        '
        Me.grpAmenities.Controls.Add(Me.chkCard)
        Me.grpAmenities.Controls.Add(Me.chkRibbon)
        Me.grpAmenities.Controls.Add(Me.chkBow)
        Me.grpAmenities.Location = New System.Drawing.Point(144, 46)
        Me.grpAmenities.Name = "grpAmenities"
        Me.grpAmenities.Size = New System.Drawing.Size(104, 118)
        Me.grpAmenities.TabIndex = 1
        Me.grpAmenities.TabStop = False
        Me.grpAmenities.Text = "Amenities"
        '
        'chkCard
        '
        Me.chkCard.AutoSize = True
        Me.chkCard.Location = New System.Drawing.Point(15, 84)
        Me.chkCard.Name = "chkCard"
        Me.chkCard.Size = New System.Drawing.Size(48, 17)
        Me.chkCard.TabIndex = 2
        Me.chkCard.Text = "Card"
        Me.chkCard.UseVisualStyleBackColor = True
        '
        'chkRibbon
        '
        Me.chkRibbon.AutoSize = True
        Me.chkRibbon.Location = New System.Drawing.Point(15, 52)
        Me.chkRibbon.Name = "chkRibbon"
        Me.chkRibbon.Size = New System.Drawing.Size(60, 17)
        Me.chkRibbon.TabIndex = 1
        Me.chkRibbon.Text = "Ribbon"
        Me.chkRibbon.UseVisualStyleBackColor = True
        '
        'chkBow
        '
        Me.chkBow.AutoSize = True
        Me.chkBow.Location = New System.Drawing.Point(15, 20)
        Me.chkBow.Name = "chkBow"
        Me.chkBow.Size = New System.Drawing.Size(47, 17)
        Me.chkBow.TabIndex = 0
        Me.chkBow.Text = "Bow"
        Me.chkBow.UseVisualStyleBackColor = True
        '
        'lblTotal
        '
        Me.lblTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotal.Location = New System.Drawing.Point(93, 179)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(100, 23)
        Me.lblTotal.TabIndex = 2
        Me.lblTotal.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(199, 179)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(49, 23)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Total"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'btnExit
        '
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(173, 220)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 30)
        Me.btnExit.TabIndex = 4
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(-2, 9)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(296, 23)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Karen Foryou Gift Wrapping"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'frmKarenForyouGiftWrapping
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(292, 273)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblTotal)
        Me.Controls.Add(Me.grpAmenities)
        Me.Controls.Add(Me.grpSize)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmKarenForyouGiftWrapping"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Gift Wrapped for that Special Touch!"
        Me.grpSize.ResumeLayout(False)
        Me.grpSize.PerformLayout()
        Me.grpAmenities.ResumeLayout(False)
        Me.grpAmenities.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents grpSize As System.Windows.Forms.GroupBox
    Friend WithEvents radLarge As System.Windows.Forms.RadioButton
    Friend WithEvents radMedium As System.Windows.Forms.RadioButton
    Friend WithEvents radSmall As System.Windows.Forms.RadioButton
    Friend WithEvents grpAmenities As System.Windows.Forms.GroupBox
    Friend WithEvents chkCard As System.Windows.Forms.CheckBox
    Friend WithEvents chkRibbon As System.Windows.Forms.CheckBox
    Friend WithEvents chkBow As System.Windows.Forms.CheckBox
    Friend WithEvents lblTotal As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label

End Class
