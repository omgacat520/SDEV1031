'Prologue

Public Class frmKarenForyouGiftWrapping

    Private Sub CalcTotal()
        Const decAmenities As Decimal = 0.5
        Dim decTotal As Decimal

        'Calc charge for package size
        If radSmall.Checked Then
            decTotal = 2.5
        ElseIf radMedium.Checked Then
            decTotal = 3.5
        Else
            decTotal = 5
        End If

        'Calc charges for amenities
        If chkBow.Checked Then
            decTotal += decAmenities
        End If
        If chkRibbon.Checked Then
            decTotal += decAmenities
        End If
        If chkCard.Checked Then
            decTotal += decAmenities
        End If

        'Display total
        lblTotal.Text = decTotal.ToString("c")

    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        End

    End Sub

    Private Sub radSmall_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radSmall.CheckedChanged
        CalcTotal()

    End Sub

    Private Sub radMedium_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radMedium.CheckedChanged
        CalcTotal()

    End Sub

    Private Sub radLarge_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radLarge.CheckedChanged
        CalcTotal()

    End Sub

    Private Sub chkBow_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkBow.CheckedChanged
        CalcTotal()

    End Sub

    Private Sub chkRibbon_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkRibbon.CheckedChanged
        CalcTotal()

    End Sub

    Private Sub chkCard_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkCard.CheckedChanged
        CalcTotal()

    End Sub

End Class
