'Prologue


Public Class frmOwtPizzaFinished
    Dim mstrSize As String
    Dim mdecPrice As Decimal
    Dim mdecTotal As Decimal
    Dim mstrStyle As String
    Dim mstrToppings As String

    Private Sub radSmall_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radSmall.CheckedChanged
        mstrSize = "Small"
        mdecPrice = 8.95

    End Sub

    Private Sub radMedium_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radMedium.CheckedChanged
        mstrSize = "Medium"
        mdecPrice = 10.95

    End Sub

    Private Sub radLarge_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radLarge.CheckedChanged
        mstrSize = "Large"
        mdecPrice = 12.95

    End Sub

    Private Sub radManholeCover_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radManholeCover.CheckedChanged
        mstrSize = "Manhole Cover"
        mdecPrice = 14.95

    End Sub

    Private Sub btnOrder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOrder.Click
        Dim strToppings As String
        Dim strReservations As String = "none"
        Dim strLocation As String
        Dim decDelivery As Decimal = 1.5

        mdecTotal += mdecPrice

        If chkPepperoni.Checked Then
            strToppings += "Pepperoni "
        End If
        If chkSausage.Checked Then
            strToppings += "Sausage "
        End If
        If chkCanadianBacon.Checked Then
            strToppings += "Canadian Bacon "
        End If
        If chkBeef.Checked Then
            strToppings += "Beef "
        End If
        If chkGreenPeppers.Checked Then
            strToppings += "Green Peppers "
        End If
        If chkOnions.Checked Then
            strToppings += "Onions "
        End If
        If chkOlives.Checked Then
            strToppings += "Olives "
        End If
        If chkMushrooms.Checked Then
            strToppings += "Mushrooms "
        End If
        If chkAnchovies.Checked Then
            strToppings += "Anchovies "
        End If

        If lstReservations.SelectedIndex > 0 Then
            strReservations = lstReservations.Items(lstReservations.SelectedIndex)
        End If

        If lstLocation.SelectedIndex >= 0 Then
            strLocation = lstLocation.Items(lstLocation.SelectedIndex)
        End If

        rtbOut.AppendText("1   " & mstrStyle.PadRight(12) & mstrSize.PadRight(12) & ControlChars.Tab & mdecPrice.ToString("c").PadLeft(12) & vbNewLine)
        rtbOut.AppendText(strToppings & vbNewLine)
        rtbOut.AppendText("Reservations: " & strReservations.PadRight(10) & strLocation & vbNewLine)

        If strLocation = "Delivery" Then
            mdecTotal += decDelivery
            rtbOut.AppendText("Delivery:                            " & decDelivery.ToString("c") & vbNewLine)
        End If

    End Sub

    Private Sub PrintHeading()
        rtbOut.Clear()
        rtbOut.AppendText("                     Owt Pizza" & vbNewLine)
        rtbOut.AppendText("            Dine-in Carryout Delivery" & vbNewLine & vbNewLine)
    End Sub

    Private Sub frmOwtPizza_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        PrintHeading()

    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        End

    End Sub

    Private Sub radThin_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radThin.CheckedChanged
        mstrStyle = "Thin"

    End Sub

    Private Sub radThick_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radThick.CheckedChanged
        mstrStyle = "Thick"

    End Sub

    Private Sub radStuffed_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radStuffed.CheckedChanged
        mstrStyle = "Stuffed"

    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        mdecTotal = 0
        PrintHeading()
        lstReservations.SelectedIndex = -1
        radMedium.Checked = True
        radThick.Checked = True
        chkPepperoni.Checked = False
        chkSausage.Checked = False
        chkCanadianBacon.Checked = False
        chkBeef.Checked = False
        chkGreenPeppers.Checked = False
        chkOnions.Checked = False
        chkOlives.Checked = False
        chkMushrooms.Checked = False
        chkAnchovies.Checked = False

    End Sub

    Private Sub btnTotal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTotal.Click
        Dim sngSalesTaxRate As Single = 0.08
        Dim decSalesTax As Decimal
        Dim decGrandTotal As Decimal

        decSalesTax = mdecTotal * sngSalesTaxRate
        decGrandTotal = mdecTotal + decSalesTax
        rtbOut.AppendText("Subtotal: " & mdecTotal.ToString("c").PadLeft(32) & vbNewLine)
        rtbOut.AppendText("Sales Tax: " & decSalesTax.ToString("c").PadLeft(31) & vbNewLine)
        rtbOut.AppendText("Your Total: " & decGrandTotal.ToString("c").PadLeft(30) & vbNewLine)

    End Sub

End Class
