<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmOwtPizzaFinished
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grpSize = New System.Windows.Forms.GroupBox
        Me.radManholeCover = New System.Windows.Forms.RadioButton
        Me.radLarge = New System.Windows.Forms.RadioButton
        Me.radMedium = New System.Windows.Forms.RadioButton
        Me.radSmall = New System.Windows.Forms.RadioButton
        Me.rtbOut = New System.Windows.Forms.RichTextBox
        Me.btnOrder = New System.Windows.Forms.Button
        Me.btnTotal = New System.Windows.Forms.Button
        Me.btnClear = New System.Windows.Forms.Button
        Me.btnExit = New System.Windows.Forms.Button
        Me.grpStyle = New System.Windows.Forms.GroupBox
        Me.radStuffed = New System.Windows.Forms.RadioButton
        Me.radThick = New System.Windows.Forms.RadioButton
        Me.radThin = New System.Windows.Forms.RadioButton
        Me.grpToppings = New System.Windows.Forms.GroupBox
        Me.chkAnchovies = New System.Windows.Forms.CheckBox
        Me.chkMushrooms = New System.Windows.Forms.CheckBox
        Me.chkBeef = New System.Windows.Forms.CheckBox
        Me.chkOlives = New System.Windows.Forms.CheckBox
        Me.chkOnions = New System.Windows.Forms.CheckBox
        Me.chkGreenPeppers = New System.Windows.Forms.CheckBox
        Me.chkCanadianBacon = New System.Windows.Forms.CheckBox
        Me.chkSausage = New System.Windows.Forms.CheckBox
        Me.chkPepperoni = New System.Windows.Forms.CheckBox
        Me.lstReservations = New System.Windows.Forms.ListBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.lstLocation = New System.Windows.Forms.ListBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.grpSize.SuspendLayout()
        Me.grpStyle.SuspendLayout()
        Me.grpToppings.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpSize
        '
        Me.grpSize.Controls.Add(Me.radManholeCover)
        Me.grpSize.Controls.Add(Me.radLarge)
        Me.grpSize.Controls.Add(Me.radMedium)
        Me.grpSize.Controls.Add(Me.radSmall)
        Me.grpSize.Location = New System.Drawing.Point(12, 12)
        Me.grpSize.Name = "grpSize"
        Me.grpSize.Size = New System.Drawing.Size(125, 145)
        Me.grpSize.TabIndex = 4
        Me.grpSize.TabStop = False
        Me.grpSize.Text = "Size"
        '
        'radManholeCover
        '
        Me.radManholeCover.Location = New System.Drawing.Point(24, 110)
        Me.radManholeCover.Name = "radManholeCover"
        Me.radManholeCover.Size = New System.Drawing.Size(97, 24)
        Me.radManholeCover.TabIndex = 3
        Me.radManholeCover.Text = "Manhole Cover"
        '
        'radLarge
        '
        Me.radLarge.Location = New System.Drawing.Point(24, 80)
        Me.radLarge.Name = "radLarge"
        Me.radLarge.Size = New System.Drawing.Size(97, 24)
        Me.radLarge.TabIndex = 2
        Me.radLarge.Text = "Large"
        '
        'radMedium
        '
        Me.radMedium.Checked = True
        Me.radMedium.Location = New System.Drawing.Point(24, 48)
        Me.radMedium.Name = "radMedium"
        Me.radMedium.Size = New System.Drawing.Size(97, 24)
        Me.radMedium.TabIndex = 1
        Me.radMedium.TabStop = True
        Me.radMedium.Text = "Medium"
        '
        'radSmall
        '
        Me.radSmall.Location = New System.Drawing.Point(24, 16)
        Me.radSmall.Name = "radSmall"
        Me.radSmall.Size = New System.Drawing.Size(97, 24)
        Me.radSmall.TabIndex = 0
        Me.radSmall.Text = "Small"
        '
        'rtbOut
        '
        Me.rtbOut.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.rtbOut.Font = New System.Drawing.Font("Courier New", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rtbOut.Location = New System.Drawing.Point(0, 310)
        Me.rtbOut.Name = "rtbOut"
        Me.rtbOut.Size = New System.Drawing.Size(392, 157)
        Me.rtbOut.TabIndex = 5
        Me.rtbOut.Text = ""
        '
        'btnOrder
        '
        Me.btnOrder.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOrder.Location = New System.Drawing.Point(11, 261)
        Me.btnOrder.Name = "btnOrder"
        Me.btnOrder.Size = New System.Drawing.Size(75, 30)
        Me.btnOrder.TabIndex = 6
        Me.btnOrder.Text = "&Order"
        Me.btnOrder.UseVisualStyleBackColor = True
        '
        'btnTotal
        '
        Me.btnTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTotal.Location = New System.Drawing.Point(109, 261)
        Me.btnTotal.Name = "btnTotal"
        Me.btnTotal.Size = New System.Drawing.Size(75, 30)
        Me.btnTotal.TabIndex = 7
        Me.btnTotal.Text = "&Total"
        Me.btnTotal.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.Location = New System.Drawing.Point(207, 261)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 30)
        Me.btnClear.TabIndex = 8
        Me.btnClear.Text = "&Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(305, 261)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 30)
        Me.btnExit.TabIndex = 9
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'grpStyle
        '
        Me.grpStyle.Controls.Add(Me.radStuffed)
        Me.grpStyle.Controls.Add(Me.radThick)
        Me.grpStyle.Controls.Add(Me.radThin)
        Me.grpStyle.Location = New System.Drawing.Point(143, 12)
        Me.grpStyle.Name = "grpStyle"
        Me.grpStyle.Size = New System.Drawing.Size(96, 112)
        Me.grpStyle.TabIndex = 10
        Me.grpStyle.TabStop = False
        Me.grpStyle.Text = "Style"
        '
        'radStuffed
        '
        Me.radStuffed.Location = New System.Drawing.Point(24, 80)
        Me.radStuffed.Name = "radStuffed"
        Me.radStuffed.Size = New System.Drawing.Size(64, 24)
        Me.radStuffed.TabIndex = 2
        Me.radStuffed.Text = "Stuffed"
        '
        'radThick
        '
        Me.radThick.Checked = True
        Me.radThick.Location = New System.Drawing.Point(24, 48)
        Me.radThick.Name = "radThick"
        Me.radThick.Size = New System.Drawing.Size(64, 24)
        Me.radThick.TabIndex = 1
        Me.radThick.TabStop = True
        Me.radThick.Text = "Thick"
        '
        'radThin
        '
        Me.radThin.Location = New System.Drawing.Point(24, 16)
        Me.radThin.Name = "radThin"
        Me.radThin.Size = New System.Drawing.Size(64, 24)
        Me.radThin.TabIndex = 0
        Me.radThin.Text = "Thin"
        '
        'grpToppings
        '
        Me.grpToppings.Controls.Add(Me.chkAnchovies)
        Me.grpToppings.Controls.Add(Me.chkMushrooms)
        Me.grpToppings.Controls.Add(Me.chkBeef)
        Me.grpToppings.Controls.Add(Me.chkOlives)
        Me.grpToppings.Controls.Add(Me.chkOnions)
        Me.grpToppings.Controls.Add(Me.chkGreenPeppers)
        Me.grpToppings.Controls.Add(Me.chkCanadianBacon)
        Me.grpToppings.Controls.Add(Me.chkSausage)
        Me.grpToppings.Controls.Add(Me.chkPepperoni)
        Me.grpToppings.Location = New System.Drawing.Point(245, 12)
        Me.grpToppings.Name = "grpToppings"
        Me.grpToppings.Size = New System.Drawing.Size(125, 230)
        Me.grpToppings.TabIndex = 5
        Me.grpToppings.TabStop = False
        Me.grpToppings.Text = "Toppings"
        '
        'chkAnchovies
        '
        Me.chkAnchovies.AutoSize = True
        Me.chkAnchovies.Location = New System.Drawing.Point(15, 200)
        Me.chkAnchovies.Name = "chkAnchovies"
        Me.chkAnchovies.Size = New System.Drawing.Size(76, 17)
        Me.chkAnchovies.TabIndex = 8
        Me.chkAnchovies.Text = "Anchovies"
        Me.chkAnchovies.UseVisualStyleBackColor = True
        '
        'chkMushrooms
        '
        Me.chkMushrooms.AutoSize = True
        Me.chkMushrooms.Location = New System.Drawing.Point(15, 177)
        Me.chkMushrooms.Name = "chkMushrooms"
        Me.chkMushrooms.Size = New System.Drawing.Size(80, 17)
        Me.chkMushrooms.TabIndex = 7
        Me.chkMushrooms.Text = "Mushrooms"
        Me.chkMushrooms.UseVisualStyleBackColor = True
        '
        'chkBeef
        '
        Me.chkBeef.AutoSize = True
        Me.chkBeef.Location = New System.Drawing.Point(15, 85)
        Me.chkBeef.Name = "chkBeef"
        Me.chkBeef.Size = New System.Drawing.Size(48, 17)
        Me.chkBeef.TabIndex = 3
        Me.chkBeef.Text = "Beef"
        Me.chkBeef.UseVisualStyleBackColor = True
        '
        'chkOlives
        '
        Me.chkOlives.AutoSize = True
        Me.chkOlives.Location = New System.Drawing.Point(15, 154)
        Me.chkOlives.Name = "chkOlives"
        Me.chkOlives.Size = New System.Drawing.Size(55, 17)
        Me.chkOlives.TabIndex = 6
        Me.chkOlives.Text = "Olives"
        Me.chkOlives.UseVisualStyleBackColor = True
        '
        'chkOnions
        '
        Me.chkOnions.AutoSize = True
        Me.chkOnions.Location = New System.Drawing.Point(15, 131)
        Me.chkOnions.Name = "chkOnions"
        Me.chkOnions.Size = New System.Drawing.Size(59, 17)
        Me.chkOnions.TabIndex = 5
        Me.chkOnions.Text = "Onions"
        Me.chkOnions.UseVisualStyleBackColor = True
        '
        'chkGreenPeppers
        '
        Me.chkGreenPeppers.AutoSize = True
        Me.chkGreenPeppers.Location = New System.Drawing.Point(15, 108)
        Me.chkGreenPeppers.Name = "chkGreenPeppers"
        Me.chkGreenPeppers.Size = New System.Drawing.Size(97, 17)
        Me.chkGreenPeppers.TabIndex = 4
        Me.chkGreenPeppers.Text = "Green Peppers"
        Me.chkGreenPeppers.UseVisualStyleBackColor = True
        '
        'chkCanadianBacon
        '
        Me.chkCanadianBacon.AutoSize = True
        Me.chkCanadianBacon.Location = New System.Drawing.Point(15, 62)
        Me.chkCanadianBacon.Name = "chkCanadianBacon"
        Me.chkCanadianBacon.Size = New System.Drawing.Size(105, 17)
        Me.chkCanadianBacon.TabIndex = 2
        Me.chkCanadianBacon.Text = "Canadian Bacon"
        Me.chkCanadianBacon.UseVisualStyleBackColor = True
        '
        'chkSausage
        '
        Me.chkSausage.AutoSize = True
        Me.chkSausage.Location = New System.Drawing.Point(15, 39)
        Me.chkSausage.Name = "chkSausage"
        Me.chkSausage.Size = New System.Drawing.Size(68, 17)
        Me.chkSausage.TabIndex = 1
        Me.chkSausage.Text = "Sausage"
        Me.chkSausage.UseVisualStyleBackColor = True
        '
        'chkPepperoni
        '
        Me.chkPepperoni.AutoSize = True
        Me.chkPepperoni.Location = New System.Drawing.Point(15, 16)
        Me.chkPepperoni.Name = "chkPepperoni"
        Me.chkPepperoni.Size = New System.Drawing.Size(74, 17)
        Me.chkPepperoni.TabIndex = 0
        Me.chkPepperoni.Text = "Pepperoni"
        Me.chkPepperoni.UseVisualStyleBackColor = True
        '
        'lstReservations
        '
        Me.lstReservations.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstReservations.FormattingEnabled = True
        Me.lstReservations.ItemHeight = 16
        Me.lstReservations.Items.AddRange(New Object() {"", "5:00", "5:15", "5:30", "5:45", "6:00", "6:15", "6:30", "6:45", "7:00", "7:15", "7:30", "7:45", "8:00", "8:15", "8:30", "8:45", "9:00"})
        Me.lstReservations.Location = New System.Drawing.Point(36, 186)
        Me.lstReservations.Name = "lstReservations"
        Me.lstReservations.Size = New System.Drawing.Size(76, 52)
        Me.lstReservations.TabIndex = 11
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(13, 166)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(124, 23)
        Me.Label1.TabIndex = 12
        Me.Label1.Text = "Reservations"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lstLocation
        '
        Me.lstLocation.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstLocation.FormattingEnabled = True
        Me.lstLocation.ItemHeight = 16
        Me.lstLocation.Items.AddRange(New Object() {"Dine-in", "Carryout", "Delivery"})
        Me.lstLocation.Location = New System.Drawing.Point(155, 186)
        Me.lstLocation.Name = "lstLocation"
        Me.lstLocation.Size = New System.Drawing.Size(76, 52)
        Me.lstLocation.TabIndex = 13
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(143, 166)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(96, 23)
        Me.Label2.TabIndex = 14
        Me.Label2.Text = "Location"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'frmOwtPizzaFinished
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(392, 467)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lstLocation)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lstReservations)
        Me.Controls.Add(Me.grpToppings)
        Me.Controls.Add(Me.grpStyle)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnTotal)
        Me.Controls.Add(Me.btnOrder)
        Me.Controls.Add(Me.rtbOut)
        Me.Controls.Add(Me.grpSize)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmOwtPizzaFinished"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Owt Pizza -- Warren and Carrie Owt Owners"
        Me.grpSize.ResumeLayout(False)
        Me.grpStyle.ResumeLayout(False)
        Me.grpToppings.ResumeLayout(False)
        Me.grpToppings.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents grpSize As System.Windows.Forms.GroupBox
    Friend WithEvents radManholeCover As System.Windows.Forms.RadioButton
    Friend WithEvents radLarge As System.Windows.Forms.RadioButton
    Friend WithEvents radMedium As System.Windows.Forms.RadioButton
    Friend WithEvents radSmall As System.Windows.Forms.RadioButton
    Friend WithEvents rtbOut As System.Windows.Forms.RichTextBox
    Friend WithEvents btnOrder As System.Windows.Forms.Button
    Friend WithEvents btnTotal As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents grpStyle As System.Windows.Forms.GroupBox
    Friend WithEvents radStuffed As System.Windows.Forms.RadioButton
    Friend WithEvents radThick As System.Windows.Forms.RadioButton
    Friend WithEvents radThin As System.Windows.Forms.RadioButton
    Friend WithEvents grpToppings As System.Windows.Forms.GroupBox
    Friend WithEvents chkOlives As System.Windows.Forms.CheckBox
    Friend WithEvents chkOnions As System.Windows.Forms.CheckBox
    Friend WithEvents chkGreenPeppers As System.Windows.Forms.CheckBox
    Friend WithEvents chkCanadianBacon As System.Windows.Forms.CheckBox
    Friend WithEvents chkSausage As System.Windows.Forms.CheckBox
    Friend WithEvents chkPepperoni As System.Windows.Forms.CheckBox
    Friend WithEvents chkMushrooms As System.Windows.Forms.CheckBox
    Friend WithEvents chkBeef As System.Windows.Forms.CheckBox
    Friend WithEvents chkAnchovies As System.Windows.Forms.CheckBox
    Friend WithEvents lstReservations As System.Windows.Forms.ListBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lstLocation As System.Windows.Forms.ListBox
    Friend WithEvents Label2 As System.Windows.Forms.Label

End Class
