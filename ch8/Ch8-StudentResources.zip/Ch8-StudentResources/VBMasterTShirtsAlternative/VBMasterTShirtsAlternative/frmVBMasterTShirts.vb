'Prologue


Public Class frmVBMasterTShirts
 
    Private Sub radSmall_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radSmall.CheckedChanged
        PlaceOrder("Small")

    End Sub

    Private Sub radMedium_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radMedium.CheckedChanged
        PlaceOrder("Medium")
    End Sub

    Private Sub radLarge_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radLarge.CheckedChanged
        PlaceOrder("Large")

    End Sub

    Private Sub radExtraLarge_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radExtraLarge.CheckedChanged
        PlaceOrder("Extra Large")

    End Sub

    Private Sub radXXL_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radXXL.CheckedChanged
        PlaceOrder("XXL")

    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        End

    End Sub

    Private Sub PlaceOrder(ByVal strSize As String)
        Dim decPrice As Decimal

        Select Case strSize
            Case Is = "Small"
                decPrice = 8
            Case Is = "Medium"
                decPrice = 8
            Case Is = "Large"
                decPrice = 10
            Case Is = "Extra Large"
                decPrice = 10
            Case Is = "XXL"
                decPrice = 12
        End Select

        lblSize.Text = strSize
        lblPrice.Text = decPrice.ToString("c")

    End Sub
End Class
