﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class jimSoxSportsSales
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtFootball = New System.Windows.Forms.TextBox()
        Me.txtBasketball = New System.Windows.Forms.TextBox()
        Me.txtVolleyball = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.lblFootbalOutput = New System.Windows.Forms.Label()
        Me.lblBasketballOutput = New System.Windows.Forms.Label()
        Me.lblVolleyballOutput = New System.Windows.Forms.Label()
        Me.lblSubtotalOutput = New System.Windows.Forms.Label()
        Me.lblTaxOutput = New System.Windows.Forms.Label()
        Me.lblTotalOutput = New System.Windows.Forms.Label()
        Me.lblTotalitems = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(31, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(49, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Footballs"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(19, 34)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(61, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Basketballs"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(24, 60)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(56, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Volleyballs"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(21, 85)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(59, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Total Items"
        '
        'txtFootball
        '
        Me.txtFootball.Location = New System.Drawing.Point(86, 6)
        Me.txtFootball.Name = "txtFootball"
        Me.txtFootball.Size = New System.Drawing.Size(65, 20)
        Me.txtFootball.TabIndex = 4
        '
        'txtBasketball
        '
        Me.txtBasketball.Location = New System.Drawing.Point(86, 31)
        Me.txtBasketball.Name = "txtBasketball"
        Me.txtBasketball.Size = New System.Drawing.Size(65, 20)
        Me.txtBasketball.TabIndex = 5
        '
        'txtVolleyball
        '
        Me.txtVolleyball.Location = New System.Drawing.Point(86, 57)
        Me.txtVolleyball.Name = "txtVolleyball"
        Me.txtVolleyball.Size = New System.Drawing.Size(65, 20)
        Me.txtVolleyball.TabIndex = 6
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(187, 9)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(40, 13)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "$44.95"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(187, 34)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(40, 13)
        Me.Label6.TabIndex = 9
        Me.Label6.Text = "$49.95"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(187, 60)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(40, 13)
        Me.Label7.TabIndex = 10
        Me.Label7.Text = "$39.95"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(181, 87)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(46, 13)
        Me.Label8.TabIndex = 11
        Me.Label8.Text = "Subtotal"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(156, 112)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(71, 13)
        Me.Label9.TabIndex = 12
        Me.Label9.Text = "Tax @ 5.00%"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(196, 154)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(31, 13)
        Me.Label10.TabIndex = 13
        Me.Label10.Text = "Total"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(258, 193)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 14
        Me.Button1.Text = "Checkout"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(258, 222)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 15
        Me.Button2.Text = "Exit"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'lblFootbalOutput
        '
        Me.lblFootbalOutput.BackColor = System.Drawing.SystemColors.Control
        Me.lblFootbalOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblFootbalOutput.Location = New System.Drawing.Point(233, 9)
        Me.lblFootbalOutput.Name = "lblFootbalOutput"
        Me.lblFootbalOutput.Size = New System.Drawing.Size(100, 24)
        Me.lblFootbalOutput.TabIndex = 16
        Me.lblFootbalOutput.Text = "lblFootballOutput"
        '
        'lblBasketballOutput
        '
        Me.lblBasketballOutput.BackColor = System.Drawing.SystemColors.Control
        Me.lblBasketballOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblBasketballOutput.Location = New System.Drawing.Point(233, 34)
        Me.lblBasketballOutput.Name = "lblBasketballOutput"
        Me.lblBasketballOutput.Size = New System.Drawing.Size(100, 24)
        Me.lblBasketballOutput.TabIndex = 17
        Me.lblBasketballOutput.Text = "lblBasketballOutput"
        '
        'lblVolleyballOutput
        '
        Me.lblVolleyballOutput.BackColor = System.Drawing.SystemColors.Control
        Me.lblVolleyballOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblVolleyballOutput.Location = New System.Drawing.Point(233, 60)
        Me.lblVolleyballOutput.Name = "lblVolleyballOutput"
        Me.lblVolleyballOutput.Size = New System.Drawing.Size(100, 24)
        Me.lblVolleyballOutput.TabIndex = 18
        Me.lblVolleyballOutput.Text = "lblVolleyballOutput"
        '
        'lblSubtotalOutput
        '
        Me.lblSubtotalOutput.BackColor = System.Drawing.SystemColors.Control
        Me.lblSubtotalOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSubtotalOutput.Location = New System.Drawing.Point(233, 86)
        Me.lblSubtotalOutput.Name = "lblSubtotalOutput"
        Me.lblSubtotalOutput.Size = New System.Drawing.Size(100, 24)
        Me.lblSubtotalOutput.TabIndex = 19
        Me.lblSubtotalOutput.Text = "lblSubtotalOutput"
        '
        'lblTaxOutput
        '
        Me.lblTaxOutput.BackColor = System.Drawing.SystemColors.Control
        Me.lblTaxOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTaxOutput.Location = New System.Drawing.Point(233, 111)
        Me.lblTaxOutput.Name = "lblTaxOutput"
        Me.lblTaxOutput.Size = New System.Drawing.Size(100, 24)
        Me.lblTaxOutput.TabIndex = 20
        Me.lblTaxOutput.Text = "lblTaxOutput"
        '
        'lblTotalOutput
        '
        Me.lblTotalOutput.BackColor = System.Drawing.SystemColors.Control
        Me.lblTotalOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTotalOutput.Location = New System.Drawing.Point(233, 154)
        Me.lblTotalOutput.Name = "lblTotalOutput"
        Me.lblTotalOutput.Size = New System.Drawing.Size(100, 24)
        Me.lblTotalOutput.TabIndex = 21
        Me.lblTotalOutput.Text = "lblTotalOutput"
        '
        'lblTotalitems
        '
        Me.lblTotalitems.AutoSize = True
        Me.lblTotalitems.BackColor = System.Drawing.SystemColors.Control
        Me.lblTotalitems.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTotalitems.Location = New System.Drawing.Point(86, 85)
        Me.lblTotalitems.Name = "lblTotalitems"
        Me.lblTotalitems.Size = New System.Drawing.Size(62, 15)
        Me.lblTotalitems.TabIndex = 22
        Me.lblTotalitems.Text = "lblTotalitem"
        '
        'jimSoxSportsSales
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(344, 257)
        Me.Controls.Add(Me.lblTotalitems)
        Me.Controls.Add(Me.lblTotalOutput)
        Me.Controls.Add(Me.lblTaxOutput)
        Me.Controls.Add(Me.lblSubtotalOutput)
        Me.Controls.Add(Me.lblVolleyballOutput)
        Me.Controls.Add(Me.lblBasketballOutput)
        Me.Controls.Add(Me.lblFootbalOutput)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtVolleyball)
        Me.Controls.Add(Me.txtBasketball)
        Me.Controls.Add(Me.txtFootball)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "jimSoxSportsSales"
        Me.Text = "Jim Soxx Sports Sales"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents txtFootball As TextBox
    Friend WithEvents txtBasketball As TextBox
    Friend WithEvents txtVolleyball As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents lblFootbalOutput As Label
    Friend WithEvents lblBasketballOutput As Label
    Friend WithEvents lblVolleyballOutput As Label
    Friend WithEvents lblSubtotalOutput As Label
    Friend WithEvents lblTaxOutput As Label
    Friend WithEvents lblTotalOutput As Label
    Friend WithEvents lblTotalitems As Label
End Class
