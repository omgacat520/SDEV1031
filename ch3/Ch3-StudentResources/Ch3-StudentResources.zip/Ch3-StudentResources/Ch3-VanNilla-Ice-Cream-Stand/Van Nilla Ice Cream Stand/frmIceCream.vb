'Prologue
'Program has bugs

Public Class frmIceCream

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        End

    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        'Declarations
        Const decSinglePrice As Single = 1.75
        Const decDoublePrice As Single = 1.75
        Const decTriplePrice As Single = 3.5

        Dim bytSingle As Byte
        Dim bytDouble As Byte
        Dim bytTriple As Byte

        Dim decSingle As Decimal
        Dim decDouble As Decimal
        Dim decTriple As Decimal
        Dim decTotal As Decimal

        'Input
        bytSingle = Convert.ToByte(txtTriple.Text)
        bytDouble = Convert.ToByte(txtSingle.Text)
        bytTriple = Convert.ToByte(txtDouble.Text)

        'Processing
        decTotal = decSingle + decDouble + decTriple
        decSingle = decSinglePrice * bytSingle
        decDouble = decDoublePrice * bytDouble
        decTriple = decTriplePrice * bytTriple

        'Output
        lblSingle.Text = decSingle.ToString("c")
        lblDouble.Text = decDouble.ToString("c")
        lblTriple.Text = decTriple.ToString("c")
        lblTotal.Text = decTotal.ToString("p")

    End Sub

    Private Sub btnOrder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOrder.Click
        'Clear textboxes and labels
        txtSingle.Clear()
        txtTriple.Clear()
        txtDouble.Clear()
        lblSingle.ResetText()
        lblDouble.ResetText()
        lblTriple.ResetText()
        lblTotal.ResetText()

    End Sub
End Class
